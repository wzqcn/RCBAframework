#pragma once
class OMC
{
};
int testOMC();
void simulateOMC();
int printf2(const char* format, ...);
void simulateOMCStorage();
