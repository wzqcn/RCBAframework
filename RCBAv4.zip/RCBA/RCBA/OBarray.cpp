#include "OBarray.h"
#include <print>

OBarray::OBarray(ull n)
{
	m_n = n;
	m_c = 0;
	m_r = 0;
	m_k = IntToStr(rand64());

	writeCallback = [this](ull index, DataBlock3 value, OP_TYPE op) 
	{
		this->write(index, op, value);
	};

	readCallback = [this](ull index) -> DataBlock3 
	{
		return this->read(index);
	};
}
OBarray::~OBarray()
{
	//;
}

void OBarray::write(ull i, OP_TYPE op, DataBlock3 v)
{
	ull c = 0;
	if (h.find(i) != h.end())
	{
		c = h[i];
	}
	r.write_t3 = time_ms();
	RCBA::write(m_k + ","+IntToStr(m_r) + ","+IntToStr(i), c, op, v);
	r.write_t4 = time_ms();

	r.write_bandwidth_perquery = RCBA::owam->report.bandwidth_per_query;
	r.total_bandwidth += r.write_bandwidth_perquery;
}
void OBarray::insert(vector<ull> values)
{
	for (ull j = 0; j < values.size(); j++)
	{
		//this[this->m_n++] = B[j];
		write(m_n++, OP_TYPE::OPTYPE_ASSIGN, DataBlock3(1,values[j]));
		r.write_bandwidth_perquery = RCBA::owam->report.bandwidth_per_query;
		r.total_bandwidth += r.write_bandwidth_perquery;
	}
}
DataBlock3 OBarray::read(ull i)
{
	//DataBlock3 result;
	r.read_t1 = time_ms();
	ull c = 0;	
	c = h[i];
	DataBlock3 result =RCBA::readAndCopy(m_k + ","+IntToStr(m_r) + ","+IntToStr(i), c,1);
//	m_c++;
	c++;
	h[i] = c;
	r.read_t2 = time_ms();
	r.read_bandwidth_perquery = RCBA::owam->report.bandwidth_per_query*m_n;
	r.total_bandwidth += r.read_bandwidth_perquery;
	return result;
}
void OBarray::reset()
{
	for (ull i = 0; i < m_n; i++)
	{
		ull c = h[i];
		DataBlock3 d = RCBA::read(m_k + "," + IntToStr(m_r) + "," + IntToStr(i), c);
		RCBA::write(m_k + "," + IntToStr(m_r + 1) + "," + IntToStr(i), 0,OP_TYPE::OPTYPE_ASSIGN,d);
	}
	m_r += 1;
	h.clear();
}

DataBlock3 OBarray::clear()
{
	DataBlock3 result;
	for (ull j = 0; j < m_n; j++)
	{
		 RCBA::read(m_k + ","+IntToStr(m_r) + ","+IntToStr(j), m_c);
	}
	h.clear();
	m_n = 0;
	return result;
}
OBarray OBarray::copy()
{
	OBarray ob(m_n);
	for (ull j = 0; j < m_n; j++)
	{
		ull c = h[j];
		DataBlock3 d = RCBA::read(m_k + "," + IntToStr(m_r) + "," + IntToStr(j), c);
		RCBA::write(m_k + "," + IntToStr(m_r + 1) + "," + IntToStr(j), 0, OP_TYPE::OPTYPE_ASSIGN, d);
		ob.write(j, OP_TYPE::OPTYPE_ASSIGN, d);
	}
	m_r += 1;//reset
	h.clear();//reset
	return ob;
}
void OBarray::merge(OBarray& B)
{
	for (ull j = 0; j < B.m_n; j++)
	{
		//this[this->m_n++] = B[j];
		write(m_n++, OP_TYPE::OPTYPE_ASSIGN, B.read(j));
	}
}
void OBarray::dump()
{
	printf("\r\n =======================\r\n n=%d\r\n",m_n);
	for (ull j = 0; j < m_n; j++)
	{
		DataBlock3 b = read(j);
		if (b.values.size() == 0)
		{
			//printf("error array! j=%lld", j);
			//return;
			printf("EMPTY ");
			continue;
		};
		printf("%lld ", b.values[0]);
	}
	printf("\r\n =======================\r\n");
}

//OC-sort; oblivious counting sort
void OBarray::sort()
{
	std::string tmp = rndStr(32);
	ull min1 = 0;
	ull max1 = 0;
	//RCBA::owam->dump();
	for (int i = 0; i < m_n; i++)
	{
		ull c = h[i];
		//DataBlock3 result = RCBA::readAndCopy(m_k + "," + IntToStr(m_r) + "," + IntToStr(i), c, 1);
		auto d= RCBA::read(m_k + "," + IntToStr(m_r) + "," + IntToStr(i), c);
		if (d.values.size() == 0)
		{
			printf("error element ! i=%d", i);
			return;
		}
		ull v = d.values[0];
		//printf("%lld ", v);
		if (i == 0)
		{
			min1 = v;
			max1 = v;
		};
	//	RCBA::write(tmp + "," + IntToStr(v), 0, OP_TYPE::OPTYPE_ASSIGN, DataBlock3(1, 0));
		RCBA::write(tmp + ","+IntToStr(v), 0, OP_TYPE::OPTYPE_ADD, DataBlock3(1, 1));
		min1 = min(min1, v);
		max1 = max(max1, v);
	}
	ull i = 0;
	ull j = 0;
	if (max1 - min1 > 1000 * m_n)
	{
		printf("Error range : % lld \r\n", max1 - min1);
		return;
	}
	for (ull j = min1; j <= max1; j++)
	{
		//if (j == 20)
		//{
		//	RCBA::owam->dump();
		//	printf("start");
		//}
		auto value= RCBA::read(tmp + "," + IntToStr(j),0);//word count
		if (value.values.size() == 0)
		{
			continue;
		}
		if (value.isEmpty())
		{
			continue;
		}
		ull v = value.values[0];//word count
		//printf("j=%lld, v=%lld ",j, v);
		//if (j == 20)
		//{
		//	printf("%d", v);
		//}
		for (ull k = 0; k < v; k++)
		{
			//if (i == m_n)
			//{
			//	break;
			//}
			RCBA::write(m_k + "," + IntToStr(m_r + 1) + "," + IntToStr(i), 0, OPTYPE_ASSIGN, DataBlock3(1, j));
			i++;
		}
	}
	m_r += 1;
	if (m_n != i)
	{
		printf("sort error!n=%lld, i=%lld",m_n,i);
		return;
	}
	m_n = i;
	h.clear();
}
//OC-sort; oblivious deduplication
void OBarray::deduplication()
{
	std::string tmp = rndStr(32);
	ull min1 = 0;
	ull max1 = 0;
	for (int i = 0; i < m_n; i++)
	{
		ull c = h[i];
		auto d = RCBA::read(m_k + "," + IntToStr(m_r) + "," + IntToStr(i), c);
		if (d.values.size() == 0)
		{
			printf("error element ! i=%d", i);
			return;
		}
		ull v = d.values[0];
		if (i == 0)
		{
			min1 = v;
			max1 = v;
		};
		RCBA::write(tmp + IntToStr(v), 0, OP_TYPE::OPTYPE_ADD, DataBlock3(1, 1));
		min1 = min(min1, v);
		max1 = max(max1, v);
	}
	ull i = 0;
	ull j = 0;
	for (ull j = min1; j <= max1; j++)
	{
		auto value = RCBA::read(tmp + IntToStr(j), 0);//word count
		if (value.values.size() == 0)
		{
			continue;
		}
		ull v = value.values[0];//word count
		//printf("%lld ", v);
		for (ull k = 0; k < 1; k++)// here v=1
		{
			RCBA::write(m_k + "," + IntToStr(m_r + 1) + "," + IntToStr(i), 0, OPTYPE_ASSIGN, DataBlock3(1, j));
			i++;
		}
	}
	m_r += 1;
	m_n = i;
	h.clear();
}
void OBarray::push_back(ull v)
{
		//this[this->m_n++]=B[j];
		write(m_n++, OP_TYPE::OPTYPE_ASSIGN, DataBlock3(1, v));
		r.write_bandwidth_perquery = RCBA::owam->report.bandwidth_per_query;
		r.total_bandwidth += r.write_bandwidth_perquery;
}

ull OBarray::GetDigit(ull num, int exp)
{
	return (num / exp) % 10;
}


std::tuple<ull,ull> OBarray::GetMaxMin()
{
	ull max1=0, min1=0;
	for (ull i = 0; i < m_n; i++)
	{
		ull c = h[i];
		DataBlock3 d = RCBA::read(m_k + "," + IntToStr(m_r) + "," + IntToStr(i), c);
		if (d.values.size() == 0) continue;
		if (i == 0)
		{
			max1 = d.values[0];
			min1 = d.values[0];
		}
		ull v = d.values[0];
		RCBA::write(m_k + "," + IntToStr(m_r + 1) + "," + IntToStr(i), 0, OP_TYPE::OPTYPE_ASSIGN, d);
		max1 = max(max1, v);
		min1 = min(min1, v);
	}
	m_r += 1;//
	h.clear();
	return std::make_tuple(max1, min1);
}
//oblivious radix sort
void OBarray::radixSort()
{
	//
	if (m_n==0) return;
	ull maxNum = std::get<0>(GetMaxMin());
	OBarray *parray[10];//local temporary pointers
	for (int i = 0; i < 10; i++)
	{
		parray[i] = new OBarray();
	}
	for (ull exp = 1; maxNum / exp > 0; exp *= 10)
	{
		for (ull i = 0; i < m_n; i++)
		{
			ull c = h[i];
			DataBlock3 d = RCBA::read(m_k + "," + IntToStr(m_r) + "," + IntToStr(i), c);
			if (d.values.size() == 0) continue;
			ull v = d.values[0];
			RCBA::write(m_k + "," + IntToStr(m_r + 1) + "," + IntToStr(i), 0, OP_TYPE::OPTYPE_ASSIGN, d);

			ull digit = GetDigit(v, exp);
			//printf("(v=%lld exp=%d digit=%lld) ", v, exp, digit);
			parray[digit]->push_back(v);
		}
		m_r += 1;
		h.clear();
		ull index = 0;
		printf("\r\n--------------\r\n");
		bool bSorted = true;
		ull lastElement = 0;
		for (int i = 0; i < 10; i++)
		{
			for (int j=0;j<parray[i]->m_n;j++)
			{
				DataBlock3 v = parray[i]->read(j);
				if (v.values.size() == 0)
				{
					printf("sort error!\n");
					return;
				}
				RCBA::write(m_k + "," + IntToStr(m_r) + "," + IntToStr(index), 0, OP_TYPE::OPTYPE_ASSIGN, v);
				//printf("%lld ", v.values[0]);
				if (v.values[0] < lastElement)
				{
					bSorted = false;
				}
				lastElement = v.values[0];

				index++;
			}
		}
		for (int i = 0; i < 10; i++)
		{
			parray[i]->clear();
		}
		if (bSorted)
		{
			break;
		}
	}
	for (int i = 0; i < 10; i++)
	{
		delete parray[i];
	}
}

void OBarray::ShowReport()
{
	printf("\n OBarray: L=%d Z=%d u=%d size=%lld\n", RCBA::owam->report.height, RCBA::owam->m_Z, RCBA::owam->m_u, m_n);
	printf("read time:%llf(ms)\n", r.read_t2 - r.read_t1);
	printf("write time:%llf(ms)\n", r.write_t4 - r.write_t3);
	printf("read bandwith per query:%lld (bytes)\n", r.read_bandwidth_perquery);
	printf("write bandwith per query:%lld (bytes)\n", r.write_bandwidth_perquery);
	printf("total bandwidth:%lld (bytes)\n", r.total_bandwidth);
}
void TestOBarray()
{
//
}