#pragma once
#include "RWtree.h"
#include "RCBA.h"
struct OBarrayReport
{
	double read_t1;//read start
	double read_t2;//read compete
	double write_t3;//write start
	double write_t4;//write complete
	ull total_bandwidth;
	ull read_bandwidth_perquery;
	ull write_bandwidth_perquery;
};
class OBarray
{
public:
    OBarray(ull n=0);
    ~OBarray();

    RWtree* owam;
    void write(ull i, OP_TYPE op, DataBlock3 v);
    void insert(vector<ull> values);
    DataBlock3 read(ull i);
    void reset();
    DataBlock3 clear();
    OBarray copy();
    void merge(OBarray& B);
    void dump();
    void sort();
    void deduplication();
    void push_back(ull v);
    ull GetDigit(ull num, int position);
    void sortBy(int p);
    std::tuple<ull, ull> GetMaxMin();
    void radixSort();
    void ShowReport();
    string m_k;
    unordered_map<ull, ull> h;
    ull m_c;
    ull m_n;
    ull m_r;
    OBarrayReport r;

private:
    // �ص���������
    using WriteCallback = std::function<void(ull, DataBlock3, OP_TYPE)>;
    using ReadCallback = std::function<DataBlock3(ull)>;

    WriteCallback writeCallback;
    ReadCallback readCallback;

public:
    // ������
    class ObarrayElement {
    private:
        ull index;
        WriteCallback writeCallback;
        ReadCallback readCallback;

    public:
        ObarrayElement(ull idx, WriteCallback write, ReadCallback read)
            : index(idx), writeCallback(write), readCallback(read) 
        {
        }

        // 1. ��ͨ��ֵ��A[5] = 100 -> f(5, 100, 0)
        ObarrayElement& operator=(DataBlock3 value) {
            if (writeCallback) {
                writeCallback(index, value, OP_TYPE::OPTYPE_ASSIGN);
            }
            return *this;
        }

        // 2. �Ӹ�ֵ��A[5] += 100 -> f(5, 100, 1)
        ObarrayElement& operator+=(DataBlock3 value) {
            if (writeCallback) {
                writeCallback(index, value, OP_TYPE::OPTYPE_ADD);
            }
            return *this;
        }

        // 3. ȡֵ������y = A[5] -> ���� readCallback
        operator DataBlock3() const 
        {
            if (readCallback) {
                return readCallback(index);
            }
            return DataBlock3();
        }
    };

    // ����[]�����
    ObarrayElement operator[](ull index) {
        return ObarrayElement(index, writeCallback, readCallback);
    }

};

