#pragma once
#include "RWtree.h"

class RCBA
{
public:
	static RWtree *owam;
	static void defaultInit(int treeHeight);
	static void Init(int treeHeight, int u);
	static DataBlock3 read(string key, int c);
	static DataBlock3 readAndCopy(string key, int c, int r=1);
	static void write(string key, int c, OP_TYPE op, DataBlock3 v);
	static void Free();
};

void testRCBA();
void TestOWC(int n);


