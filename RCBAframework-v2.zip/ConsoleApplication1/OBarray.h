#pragma once
#include "RWtree.h"
#include "RCBA.h"
struct OBarrayReport
{
	double read_t1;//read start
	double read_t2;//read compete
	double write_t3;//write start
	double write_t4;//write complete
	ull total_bandwidth;
	ull read_bandwidth_perquery;
	ull write_bandwidth_perquery;
};
class OBarray
{
public:
	OBarray(ull n);
	RWtree* owam;
	void update(ull i, OP_TYPE op, DataBlock3 v);
	DataBlock3 read(ull i);
	DataBlock3 free();
	void ShowReport();
	string m_k;
	ull m_c;
	ull m_n;
	OBarrayReport r;
};

