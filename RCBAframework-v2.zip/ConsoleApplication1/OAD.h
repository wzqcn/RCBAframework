#pragma once
#include "RWtree.h"
class OAD
{
	public:
		RWtree* tree;
		OAD(int height);
		~OAD();
		int m_height;		
		ull Read(string key);
		void Write(string key, ull b);
		void Add(string key, ull b);	

};

