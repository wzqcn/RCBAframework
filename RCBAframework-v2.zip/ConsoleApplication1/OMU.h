#pragma once
#include "RWtree.h"
class OMU
{
public:
	RWtree* tree;
	OMU(int height);
	~OMU();
	int m_height;
	ull Read(string key);
	void Write(string key, ull b);
	void Mul(string key, ull b);

};


