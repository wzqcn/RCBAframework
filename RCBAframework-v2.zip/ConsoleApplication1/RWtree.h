#pragma once

#pragma once

#include "common.h"
#include "unordered_map"
#include "CPath64.h"
#include "myhash.h"
#include "myAES.h"
#include <vector>
#include <algorithm>
#include <string>
#define ull unsigned long long
#define DUMMY_VALUE 888888888888




struct ENode3
{
	//vector<Slot> slots;
	vector<unsigned char> bytes;
	int level;
	string path;
};

typedef unordered_map<string, ENode3> ENodes3;


struct IndexKey3 
{
	unsigned char buf[8];

	bool operator==(const IndexKey3& other)  const
	{
		return memcmp(buf, other.buf, sizeof(IndexKey3)) == 0;
	}
	void print()
	{
		printf("\n(");
		for (int i=0;i<4;i++)
		{
			printf("%.2x,", buf[i]);
		}
		printf("..)");
	}
};

namespace std {
	template<>
	struct hash<IndexKey3> 
	{
		size_t operator()(const IndexKey3& key) const {
			size_t hash = 0;
			return *(ull*)key.buf;
			/*
			for (size_t i = 0; i < sizeof(key.buf); ++i) 
			{
				hash = hash * 131 + key.buf[i];
			}*/
			//return hash;
		}
	};
}

struct DataBlock3
{
	vector<ull> values;// 
	DataBlock3()
	{
	};
	DataBlock3(int u, int v)
	{
		Init(u);
		SetAll(v);
	};
	void Init(int u)
	{
		for (int i = 0; i < u; i++)
		{
			values.push_back(DUMMY_VALUE);
		}
	}
	void SetAll(ull v)
	{
		for (int i = 0; i < values.size(); i++)
		{
			values[i] = v;
		}
	}
	void SetEmpty()
	{
		for (int i = 0; i < values.size(); i++)
		{
			values[i] = DUMMY_VALUE;
		}
	}
	bool isEmpty()
	{
		for (auto i : values)
		{
			if (i != DUMMY_VALUE) return false;
		}
		return true;
	}
	void print()
	{
		printf("\n(");
		for(auto i : values)
		{
			if (i == DUMMY_VALUE) printf(",");
			else
				printf("%lld,", i);
		}
		printf(")");
	}
};

struct Slot3
{
	IndexKey3 key;
	DataBlock3 value;//

	BYTE bOP;//0 
	void GenEmptySlot(int u)
	{
		memset(&key, 0, sizeof(key));
		value.values.clear();
		for (int i = 0; i < u; i++)
		{
			value.values.push_back(DUMMY_VALUE);
		}
	}
	bool isEmpty()
	{
		for (auto i : value.values)
		{
			if (i != DUMMY_VALUE) return false;
		}
		return true;
	}
};

struct StashItem
{
	IndexKey3 key;
	DataBlock3 value;
	int level;
	ull bOP;


	bool operator<(const StashItem& other) const
	{
		return level > other.level; //
	}
	Slot3 ToSlot3()
	{
		Slot3 sl;
		sl.key = key;
		sl.value = value;
		sl.bOP = bOP;
		return sl;
	}
};

struct TreeNode3
{
	vector<Slot3> slots;
	int level;
	string path;
	void GenEmptyNode(int Z, int u)
	{
		DataBlock3 db;
		Slot3 sl;
		sl.key = { 0 };
		db.values.clear();
		for (int i = 0; i < u; i++) db.values.push_back(DUMMY_VALUE);
		sl.value = db;
		//sl.leaf = 0;
		slots.clear();
		for (int i = 0; i < Z; i++)
		{
			slots.push_back(sl);
		}
	}
	bool isEmpty()
	{
		for (auto s : slots)
		{
			if (!s.isEmpty()) return false;
		}
		return true;
	}
};

typedef unordered_map<string, TreeNode3*> TreeNodes3;

/*
struct hash_func3
{
	size_t operator()(const IndexKey3& addr) const
	{
		return *(ull*)addr.buf;
	}
};
*/


struct HashFunc3 {
	size_t operator()(const IndexKey3& key) const {
		size_t hash = 0;
		for (size_t i = 0; i < sizeof(key.buf); ++i) {
			hash = hash * 131 + key.buf[i]; // 
		}
		return hash;
	}

};
struct cmp_fun3 //
{
	bool operator()(const IndexKey3& a1, const IndexKey3& a2) const
	{
		return memcmp(a1.buf, a2.buf, sizeof(a1)) == 0 ? true : false;
	}
};

struct Report3
{
	ull num_of_access;//
	ull current_stash_size;//
	ull max_stash_size;//
	ull last_stash_evict;//
	ull total_bandwidth;//
	ull bandwidth_per_query;//
	ull num_of_real_blocks;//
	ull num_of_real_blocks_in_tree;//
	int num_of_positionmap;//
	ull num_of_AES;//
	ull num_of_AES_decrypt;// 
	ull num_of_Black2b;//
	double t1;//
	double t2;//
	double t3;//
	double t4;//
	int height;//
	int capacity;// 
	int u;//	
};

enum OP_TYPE
{
	OPTYPE_ASSIGN=0,
	OPTYPE_ADD
};

class RWtree
{
public: RWtree(int height, int Z, int u);
	  ull KeyToLeaf(IndexKey3 indexkey);
	  ull strKeyToLeaf(string mainKey);
	  IndexKey3 ToIndexKey3(string str);
	  ull GetReadCount(IndexKey3 ik);

	  std::unordered_map<IndexKey3, ull> * pPositionMap;
	  std::unordered_map<IndexKey3, StashItem> stash;
	  vector<StashItem> stashTemp;
	  unordered_map<string, ENode3> oram;
	  DataBlock3 (*User_Defined_Operation)(DataBlock3 b1, DataBlock3 b2);
	  void TGMA();

	  bool Write(OP_TYPE op_type, string key, vector<ull> value);
	  DataBlock3 Read(string key);


	  void updateReport();
	  void dumpLevels();
	  void ShowReport();
	  ull GetStashSize();
	  ull GetN();
	  DataBlock3 User_Defined_ADD(DataBlock3 b1, DataBlock3 b2);


	  void evictPathsPATHORAM(unordered_map<string, TreeNode3>& pathNodes, vector<unsigned long long> leafs);

	  ENodes3 RebuildPaths(vector<ull>& leafs);

	  void EvictPath(ull v);

	  void EncryptPaths(unordered_map<string, TreeNode3>& pathNodes, ENodes3& enodes);
	  void writePath(ENodes3 nodes);
	  bool isEmptyBlock(DataBlock3& b);
	  void dump();

	  Report3 report;


	  int m_L;
	  int m_Z;
	  int m_u;
	  int m_capacity;
	  int m_firstLeafID;
	  int m_leafCount;
private:
	void init();
	ENode3 EncryptNode(TreeNode3 d);
	ENodes3 EncryptNodes(TreeNodes3 d);
	TreeNodes3 DecryptNodes(ENodes3 e);
	TreeNode3 DecryptNode(ENode3 e);
	ENodes3 ReadPath(unsigned long long leaf);
	void WriteIntoStash(ENodes3 enodes);
	void initAES();

	vector<vector<ull>> oneNode;
};

unordered_map<IndexKey3, ull>* GenPositionMap();
