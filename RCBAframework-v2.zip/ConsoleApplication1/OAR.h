#pragma once
#include "RWtree.h"

class OAR
{
public:
	RWtree* o3mu;
	OAR(int height,bool bCompressed);
	~OAR();
	int m_height;
	bool m_bCompressed;
	ull Read(string key);
	void Write(string key, ull b);
	void Add(string key, ull b);
	void Mul(string key, ull b);

};

