#pragma once
#include "common.h"
class encryption
{
public:
	encryption();
	~encryption();
};

