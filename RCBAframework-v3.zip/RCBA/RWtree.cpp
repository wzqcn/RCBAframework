#include "RWtree.h"
#include "math.h"
#include <cassert> 
RWtree::RWtree(int height, int Z, int u)
{
	m_L = height;
	m_Z = Z;
	m_u = u;
	init();
}
void RWtree::initAES()
{
	myAES::SetPrivateKey((char*)"12345678");
}
void RWtree::init()
{
	//pPositionMap = NULL;
	m_capacity = pow(2, m_L) - 1;// +1;
	m_firstLeafID = pow(2, m_L - 1) - 1;
	m_leafCount = pow(2, m_L - 1);
	ull mem = m_capacity * m_Z * 5;//
	ull maxMem = pow(2, 26);
	if (mem > oram.max_bucket_count()) mem = oram.max_bucket_count();//
	if (mem > maxMem) mem = maxMem;//
	oram.reserve(mem);
	initAES();
	memset(&report, 0, sizeof(report));
	report.u = m_u;
	report.height = m_L;
	report.capacity = m_capacity;
}
ENode3 RWtree::EncryptNode(TreeNode3 d)
{
	ENode3 ed;
	ed.level = d.level;
	ed.path = d.path;

	Slot3 s ;
	s.GenEmptySlot(m_u);
	if (d.slots.size() == 0)
	{
		for (int i = 0; i < m_Z; i++)
		{
			d.slots.push_back(s);
		}
	}
	int slotSize = sizeof(IndexKey3) + m_u * sizeof(ull) + sizeof(BYTE);
	int insize = d.slots.size() * slotSize;
	int outsize = 0;

	char* m = (char*)malloc(insize);
	char* output = (char*)malloc(insize * 2);
	char* p = NULL;
	for (int i = 0; i < d.slots.size(); i++)
	{
		p = m + i * slotSize;
		memcpy(p, (char*)&d.slots[i].key, sizeof(d.slots[i].key));
		p += sizeof(d.slots[i].key);//
		for (int j = 0; j < d.slots[i].value.values.size(); j++)
		{
			memcpy(p, (char*)&d.slots[i].value.values[j], sizeof(ull));//
			p += sizeof(ull);
		}
		memcpy(p, (char*)&d.slots[i].bOP, sizeof(BYTE));
	}

	myAES::Encrypt(m, insize, output, outsize);//
	report.num_of_AES++;
	for (int i = 0; i < outsize; i++)
	{
		ed.bytes.push_back(output[i]);//
	}
	free(output);
	free(m);

	return ed;
}
TreeNode3 RWtree::DecryptNode(ENode3 e)
{
	TreeNode3 d;
	d.GenEmptyNode(m_Z, m_u);
	d.path = e.path;
	d.level = e.level;
	int insize = e.bytes.size();
	char* m = (char*)malloc(insize);
	for (int i = 0; i < insize; i++)
	{
		m[i] = e.bytes[i];
	}
	char* plaintext = (char*)malloc(insize);
	int outsize = 0;
	int slotSize = sizeof(IndexKey3) + m_u * sizeof(ull) + sizeof(BYTE);
	myAES::Decrypt(m, insize, plaintext, outsize);
	report.num_of_AES_decrypt++;
	int outBlock = outsize / slotSize;//

	char* p1 = m;
	char* p2 = plaintext;
	int len = 0;
	//outBlock==m_Z
	for (int i = 0; i < outBlock; i++)
	{
		p1 = (char*)&d.slots[i].key;
		memcpy(p1, p2, sizeof(d.slots[i].key));//
		p2 += sizeof(d.slots[i].key);
		for (int j = 0; j < m_u; j++)
		{
			p1 = (char*)&d.slots[i].value.values[j];
			memcpy(p1, p2, sizeof(ull));//
			p2 += sizeof(ull);
		}
		p1 = (char*)&d.slots[i].bOP;
		memcpy(p1, p2, sizeof(BYTE));//
		p2 += sizeof(BYTE);
	}
	free(m);
	free(plaintext);
	return d;
}

ENodes3 RWtree::EncryptNodes(TreeNodes3 d)
{
	ENodes3 temp;
	for (auto v : d)
	{
		auto value = EncryptNode(*v.second);
		temp[v.first] = value;
	}
	return temp;
}

TreeNodes3 RWtree::DecryptNodes(ENodes3 e)
{
	TreeNodes3 t;
	for (auto v : e)
	{
		TreeNode3* t1 = new TreeNode3();
		*t1 = DecryptNode(v.second);
		t[v.first] = t1;
	}
	return t;
}
IndexKey3 RWtree::ToIndexKey3(string str)
{
	IndexKey3 k = { 0 };
	unsigned char buf[32] = { 0 };
	myhash::Blake2b((void*)str.c_str(), str.length(), buf);
	memcpy(k.buf, buf, sizeof(k));
	return k;
}

ull RWtree::GetReadCount(IndexKey3 ik)
{
	//ull GetReadCount(IndexKey ik)
	if (pPositionMap == NULL)
	{
		printf("no position map!");
		return 0;
	}
	ull c=(*pPositionMap)[ik];
	return c;
};
//mainKey  [0, N-1]
ull RWtree::strKeyToLeaf(string mainKey)
{
	IndexKey3 k1 = ToIndexKey3(mainKey);	
	return KeyToLeaf(k1);
	
}
ull RWtree::KeyToLeaf(IndexKey3 key)
{
	int c = GetReadCount(key);//
	string privatekey = "123456";
	string k = privatekey + IntToStr(c);//

	unsigned char buf[32] = { 0 };
	char buf2[64] = { 0 };
	memcpy(buf2, key.buf, sizeof(key));
	memcpy(buf2 + sizeof(key), k.c_str(), k.length());
	int len;
	len = sizeof(key) + k.length();

	myhash::Blake2b((void*)buf2, len, buf);
	report.num_of_Black2b++;
	ull v = *(ull*)buf;
	ull cap = (ull)pow(2, m_L - 1); // (ull)pow(2, m_L - 1)* m_Z;
	v = v % (ull)cap + m_firstLeafID;//

	return v; //
}


ENodes3 RWtree::ReadPath(unsigned long long leaf)
{
	CPath64 p(leaf);
	ENodes3 nodes;
	while (true)
	{
		string path = p.ToString();
		if (oram.find(path) == oram.end())
		{
			ENode3 empty;
			empty.path = path;
			empty.level = p.GetLevel();
			nodes[path] = empty;
			if (p.value == 0) break;
			p = p.Father();
			continue;
		}
		ENode3 n = oram[path];
		nodes[path] = n;
		if (p.value == 0) break;
		p = p.Father();
	}
	return nodes;
}

bool RWtree::isEmptyBlock(DataBlock3& b)
{
	for (int i = 0; i < m_u; i++)
	{
		if (b.values[i] != DUMMY_VALUE) return false;
	}
	return true;
}

void RWtree::WriteIntoStash(ENodes3 enodes)
{
	stashTemp.clear();
	for (auto v : enodes)
	{
		TreeNode3 d = DecryptNode(v.second);
		for (auto& s : d.slots)
		{
			if (isEmptyBlock(s.value)) continue;//
			
			StashItem it;
			it.key = s.key;
			it.value = s.value;
			it.bOP = s.bOP;
			it.level = d.level;
			//stash[s.key] = it; //
			stashTemp.push_back(it);
		}
	}
	for (auto& v : stash)
	{
		stashTemp.push_back(v.second);
	}
}

DataBlock3 RWtree::User_Defined_ADD(DataBlock3 b1, DataBlock3 b2)
{
	DataBlock3 db(m_u, 0);
	assert(b1.values.size() == b2.values.size());
	if ((b1.values.size() != m_u)|| (b2.values.size()!=m_u))
	{
		printf("error block size %d", m_u);
		return db;
	}

	//
	for (int i = 0; i < b1.values.size(); i++)
	{
		db.values[i] = b1.values[i] + b2.values[i];
	}
	return db;
}


void RWtree::TGMA()
{
	//
	unordered_map<IndexKey3, vector<StashItem>> tempmap;
	for (auto i : stashTemp)
	{
		if (tempmap.find(i.key) == tempmap.end())
		{
			vector<StashItem> v;
			v.push_back(i);
			tempmap[i.key] = v;
		}
		else
		{
			vector<StashItem> v= tempmap[i.key];
			assert(v[0].key == i.key);
			v.push_back(i);
			tempmap[i.key] = v;
		}
	//	vector<StashItem> v= tempmap[i.key];
	//	v.push_back(i);
	//	tempmap[i.key]=v;//
	}
	//unordered_map<IndexKey3, StashItem, hash_func3, cmp_fun3> stash2;
	stash.clear();
	for (auto i : tempmap)
	{
		IndexKey3 k = i.first;
		vector<StashItem> g = i.second;		
		assert(g.size() > 0);
		std::sort(g.begin(), g.end());
		DataBlock3 d(m_u,0);
		int op= g[g.size()-1].bOP;//
		bool bHasAssign = false;
		for (auto& j : g)
		{
			assert(j.key == k);
			if (j.bOP == OPTYPE_ASSIGN)
			{
				d = j.value;
				bHasAssign = true;
				continue;
			}
			if (j.bOP == OPTYPE_ADD)
			{
				if (User_Defined_Operation)
				{
					d = User_Defined_Operation(d, j.value);
				}
				else
				{
					d = User_Defined_ADD(d, j.value);
				}
				continue;
			}
			d = j.value;//
		}
		if (bHasAssign) op = OPTYPE_ASSIGN;//
		StashItem it;
		it.value = d;
		it.key = k;
		it.bOP = op;
		it.level = 0;//
		stash[k] = it;//Indexkey3 		
		//stash.push_back(it);
	}
}

//op="add"
//op='assign'

bool RWtree::Write(OP_TYPE op_type, string key, vector<ull> value)
{
	report.num_of_access++;//
	report.t1 = time_ms();
	ull randLeaf = CPath64(0).RandomLeaf(m_L);

	auto path = ReadPath(randLeaf);
	WriteIntoStash(path);
	bool bExist = false;

	StashItem it;
	it.key = ToIndexKey3(key);
	DataBlock3 b;
	bExist = (stash.find(it.key) != stash.end());
	it.value.values = value;
	it.bOP = op_type;
	it.level = 0;
	stashTemp.push_back(it);

	TGMA();//
	EvictPath(randLeaf);//stash 

	//
	report.current_stash_size = stash.size();
	if (report.max_stash_size < report.current_stash_size) report.max_stash_size = report.current_stash_size;
	report.t2 = time_ms();
	return bExist;
}

DataBlock3 RWtree::Read(string key)
{
	report.t3 = time_ms();
	ull leaf = strKeyToLeaf(key);
	DataBlock3 b;

	auto path = ReadPath(leaf);
	WriteIntoStash(path);
	bool bExist = false;

	StashItem it;
	it.key = ToIndexKey3(key);
	
	TGMA();//
	bExist = (stash.find(it.key) != stash.end());	
	if (!bExist)
	{
		//b.SetEmpty();
		report.t4 = time_ms();
		return b;
	}
	b = stash[it.key].value;
	stash.erase(it.key);//


	EvictPath(leaf);//stash ����

	//������Ϣ
	report.current_stash_size = stash.size();
	if (report.max_stash_size < report.current_stash_size) report.max_stash_size = report.current_stash_size;
	report.t4 = time_ms();
	return b;
}



void RWtree::evictPathsPATHORAM(unordered_map<string, TreeNode3>& pathNodes, vector<unsigned long long> leafs)
{
	//vector< IndexKey2> toBeDelete;
	int num_of_evict = 0;
	for (int i = m_L; i >= 1; i--)
	{
		for (auto leaf : leafs)
		{
			CPath64 currentLeaf(leaf);
			TreeNode3 node;
			//string p1 = currentLeaf.AtLevelPath(i);
			ull p1long = currentLeaf.AtLevelPathFast(i, m_L);
			string p1 = NumberToPath(p1long);
			node = pathNodes[p1];
			//toBeDelete.clear();
			node.path = p1;
			node.level = i;
			for (auto v = stash.begin(); v != stash.end();)
			{
				//int level = path64.Cross(leaf, v.second.leaf).GetLevel();	
				double t1 = time_ms();
				IndexKey3 ik = (*v).first;
				ull leaf2 = KeyToLeaf(ik);
				ull p2long = CPath64(leaf2).AtLevelPathFast(i, m_L); 
				double t2 = time_ms();


				if (p1long == p2long) 
				{
					Slot3 s;
					IndexKey3 k0;
					k0 = v->first;
					
					s = (*v).second.ToSlot3();
					if (node.slots.size() < m_Z) //
					{
						node.slots.push_back(s);
						v++;
						stash.erase(s.key);
						num_of_evict++;
					}
					else
					{
						v++;
						break;//
					}
					pathNodes[p1] = node;
				}
				else
				{
					v++;
				}
			}

		}
	}

	report.last_stash_evict = num_of_evict;
}


ENodes3 RWtree::RebuildPaths(vector<ull>& leafs) //
{
	unordered_map<string, TreeNode3> nodes;
	evictPathsPATHORAM(nodes, leafs);
	ENodes3 enodes;
	EncryptPaths(nodes, enodes);//
	return  enodes;
}


void RWtree::EvictPath(ull v)
{
	int stashSize = stash.size();
	if (stashSize == 0) return;
	vector<ull> leafs = { v };
	ENodes3 enodes = RebuildPaths(leafs); //
	writePath(enodes);//


	int size = 0;
	for (auto& x : enodes)
	{
		//
		size += x.second.bytes.size();
	}
	report.bandwidth_per_query = size * 2;
	report.total_bandwidth += size * 2;
}

void RWtree::EncryptPaths(unordered_map<string, TreeNode3>& pathNodes, ENodes3& enodes)
{
	for (auto& v : pathNodes)
	{
		TreeNode3 node = v.second;

		if (v.first != "")
		{
			while (node.slots.size() < m_Z) //
			{
				Slot3 empty;
				empty.GenEmptySlot(m_u);
				node.slots.push_back(empty);
			}
		}
		node.path = v.first;
		node.level = v.first.length() + 1;
		if (node.level == 1) 
		{
			while (node.slots.size() < m_Z) //
			{
				Slot3 empty;
				empty.GenEmptySlot(m_u);
				node.slots.push_back(empty);
			}
		}
		ENode3 enode = EncryptNode(node);
		enodes[node.path] = enode;
	}
}

void RWtree::writePath(ENodes3 nodes)
{
	for (auto d : nodes)
	{
		oram[d.first] = d.second;
	}
}



void RWtree::updateReport()
{
	//
	unordered_map<ull, ull> levelReal;
	unordered_map<ull, ull> levelEmpty;
	report.num_of_real_blocks = 0;
	report.num_of_real_blocks_in_tree = 0;
	for (auto v : oram)
	{
		ull level = v.first.length() + 1;
		auto node = v.second;
		auto node2 = DecryptNode(node);
		for (auto s : node2.slots)
		{
			if (s.isEmpty())
			{
				levelEmpty[level]++;
			}
			else
			{
				levelReal[level]++;
				report.num_of_real_blocks++;
				report.num_of_real_blocks_in_tree++;
			}
		}
	}
	report.num_of_real_blocks += stash.size();
}
void RWtree::dumpLevels()
{
	//
	unordered_map<ull, ull> levelReal;
	unordered_map<ull, ull> levelEmpty;
	report.num_of_real_blocks_in_tree = 0;
	for (auto v : oram)
	{
		ull level = v.first.length() + 1;
		auto node = v.second;
		auto node2 = DecryptNode(node);
		for (auto s : node2.slots)
		{
			if (s.isEmpty())
			{
				levelEmpty[level]++;
			}
			else
			{
				levelReal[level]++;
				report.num_of_real_blocks_in_tree++;
			}
		}
	}
	for (int i = 1; i < m_L; i++)
	{
		ull r = levelReal[i];
		ull e = levelEmpty[i];
		ull f = r + e;
		if (f > 0)
		{
			printf("Level=%d  capacity=%lld used=%lld unused=%lld usage=%.2f%%\r\n", i, f, r, e, (double)r / f * 100);
		}
		else
		{
			printf("Level=%d capacity=%lld used=%lld unused=%lld usage=0%%\r\n", i, f, r, e, 0);
		}
	}
	printf("Stash size:%lld  the number of elements in RW-tree:%lld\r\n", stash.size(), report.num_of_real_blocks_in_tree);
}
void RWtree::dump()
{
	unsigned long long size = 0;
	printf("\r\n//-----------------------------------------");
	for (auto t : oram)
	{
		ENode3 ed = t.second;
		auto d = DecryptNode(ed);
		CPath64 p;
		p.LoadPath(t.first);
		bool header = false;
		
		for (int j = 0; j < d.slots.size(); j++)
		{
			if (isEmptyBlock(d.slots[j].value))
			{
				//printf("()");
				continue;
			}
			else
			{
				if (!header)
				{
					printf("\r\n path=%s :", t.first.c_str());
					header = true;
				}
				auto s = d.slots[j];
				printf("(%.2x%.2x %.2x%.2x, size=%lld, data[0]=%lld bOP=%lld leafpath=%s)", s.key.buf[0], s.key.buf[1], s.key.buf[2], s.key.buf[3], s.value.values.size(),s.value.values[0], s.bOP, CPath64(s.bOP).ToString().c_str());
			}
		}
		//printf("]");
	}
}
void RWtree::ShowReport()
{
	Report3 r;
	RWtree* p = this;
	p->updateReport();
	r = p->report;
	printf("---------------\n Tree height:%d \n", r.height);
	printf("capacity:%lld \n", r.capacity);
	printf("Write time��%lf(ms)\n", report.t2 - report.t1);
	printf("Read time��%lf(ms)\n", report.t4 - report.t3);
	printf("Block size:%d \n", r.u);
	printf("The number of accesses:%lld \n", r.num_of_access);
	printf("Current stash size:%lld \n", r.current_stash_size);
	printf("Max stash size:%lld \n", r.max_stash_size);
	printf("The number of blocks in the tree:%lld \n", r.num_of_real_blocks_in_tree);
	printf("real blocks:%lld \n", r.num_of_real_blocks);
	printf("last evicted:%lld \n", r.last_stash_evict);
	printf("total bandwidth��byte��:%lld \n", r.total_bandwidth);
	printf("bandwdith per query��byte����%lld \n", r.bandwidth_per_query);
	printf("the number of average bandwdith per query��byte����%lld \n", r.total_bandwidth / r.num_of_access);
	printf("position map size %d \n", p->pPositionMap->size());
	printf("#AES��%lld \n", r.num_of_AES);
	printf("#AES decryption��%lld \n", r.num_of_AES_decrypt);
	printf("#blake2b:%lld \n", r.num_of_Black2b);
	p->dumpLevels();
}
ull RWtree::GetStashSize()
{
	return stash.size();
}
ull RWtree::GetN()
{
	updateReport();
	return report.num_of_real_blocks_in_tree;
}

unordered_map<IndexKey3, ull>* GenPositionMap()
{
	auto p = new unordered_map<IndexKey3, ull>();
	return p;
}
void dump_levels()
{
	//
}