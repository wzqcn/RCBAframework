#include "OAD.h"
//#include "cassert.h"

DataBlock3 myOADOperation(DataBlock3 b1, DataBlock3 b2)
{
	DataBlock3 b(1,0);
	//assert(b1.values.size() == 1);
	b.values[0]=b1.values[0] + b2.values[0];
	return b;
}

OAD::OAD(int height)
{
	tree = new RWtree(height, 4, 1); 
	tree->pPositionMap = GenPositionMap();
	tree->User_Defined_Operation = myOADOperation;
	m_height = height;
}

OAD::~OAD()
{
	delete tree;
}

ull OAD::Read(string key)
{
	DataBlock3 b = tree->Read(key);
	if (b.values.size() == 0) return NULL;
	return b.values[0];
}

void OAD::Write(string key, ull b)
{
	tree->Write(OPTYPE_ASSIGN, key, { b });
}

void OAD::Add(string key, ull b)
{
	tree->Write(OPTYPE_ADD, key, { b });
	
}
