#pragma once
#include "RWtree.h"

class RCBA
{
public:
	static RWtree *owam;
	static void defaultInit(int treeHeight);
	static void Init(int treeHeight, int u);
	static DataBlock3 read(string key, int c);
	static DataBlock3 copy(string key, int c, int r);
	static void write(string key, int c, OP_TYPE op, DataBlock3 v);
};

void testRCBA();
void TestOWC(int n);


