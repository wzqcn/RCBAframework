#include "OMU.h"


DataBlock3 myOMUOperation(DataBlock3 b1, DataBlock3 b2)
{
	if ((b1.values[0] == 0))
	{
		return b2;
	};
	DataBlock3 b(1, 0);
	//assert(b1.values.size() == 1);
	b.values[0] = b1.values[0] * b2.values[0];
	return b;
}

OMU::OMU(int height)
{
	tree = new RWtree(height, 4, 1);
	tree->pPositionMap = GenPositionMap();
	tree->User_Defined_Operation = myOMUOperation;
	m_height = height;
}

OMU::~OMU()
{
	delete tree->pPositionMap;
	delete tree;
}

ull OMU::Read(string key)
{
	DataBlock3 b = tree->Read(key);
	if (b.values.size() == 0) return NULL;
	return b.values[0];
}

void OMU::Write(string key, ull b)
{
	tree->Write(OPTYPE_ASSIGN, key, { b });
}

void OMU::Mul(string key, ull b)
{
	tree->Write(OPTYPE_ADD, key, { b });
}
