#include "OAR.h"

DataBlock3 myMulOperation(DataBlock3 b1, DataBlock3 b2)
{
	DataBlock3 b(4, 0);
	if ((b1.values[0] == 0) && (b1.values[1] == 0) && (b1.values[2] == 0) && (b1.values[3] == 0))
	{
		//b.values[0] == 1;
		//b.values[2] == 1;
		return b2;
	};
	//matrix multiplication
	b.values[0] = b1.values[0] * b2.values[0] + b1.values[1] * b2.values[2];
	b.values[1] = b1.values[0] * b2.values[1] + b1.values[1] * b2.values[3];
	b.values[2] = b1.values[2] * b2.values[0] + b1.values[3] * b2.values[2];
	b.values[3] = b1.values[2] * b2.values[1] + b1.values[3] * b2.values[3];
	//	printf("(%lld %lld)  + (%lld %lld) => (%lld %lld)\n", b1.values[0], b1.values[1], b2.values[0], b2.values[1], b.values[0], b.values[1]);
	return b;
}

DataBlock3 myMulOperationCompressed(DataBlock3 b11, DataBlock3 b22)
{
	
	if ((b11.values[0] == 0) && (b11.values[1] == 0))
	//if ( (b11.values[1] == 0))
	{		
		return b22;
	};
	
	DataBlock3 b(4, 0);
	DataBlock3 b1(4, 0);
	DataBlock3 b2(4, 0);
	b1.values[0] = b11.values[0];
	b1.values[1] = 1;
	b1.values[2] = b11.values[1];
	b1.values[3] = 0;

	b2.values[0] = b22.values[0];
	b2.values[1] = 0;
	b2.values[2] = b22.values[1];
	b2.values[3] = 1;

	//matrix multiplication
	b.values[0] = b1.values[0] * b2.values[0] + b1.values[1] * b2.values[2];
	b.values[1] = b1.values[0] * b2.values[1] + b1.values[1] * b2.values[3];
	b.values[2] = b1.values[2] * b2.values[0] + b1.values[3] * b2.values[2];
	b.values[3] = b1.values[2] * b2.values[1] + b1.values[3] * b2.values[3];
	//	printf("(%lld %lld)  + (%lld %lld) => (%lld %lld)\n", b1.values[0], b1.values[1], b2.values[0], b2.values[1], b.values[0], b.values[1]);

	DataBlock3 ret(2, 0);
	ret.values[0] = b.values[0];
	ret.values[1] = b.values[2];
	return ret;
}
OAR::OAR(int height,bool bCompressed)
{
	m_bCompressed = bCompressed;
	if (m_bCompressed)
	{
		o3mu = new RWtree(height, 4, 2); // 
	}
	else
	{
		o3mu = new RWtree(height, 4, 4); // u=4
	}
	o3mu->pPositionMap = GenPositionMap();
	if (bCompressed)
	{
		o3mu->User_Defined_Operation = myMulOperationCompressed;

	}
	else
	{
		o3mu->User_Defined_Operation = myMulOperation;
	}

	m_height = height;
}
OAR::~OAR()
{
	delete o3mu->pPositionMap;
	delete o3mu;
}

ull OAR::Read(string key)
{
	DataBlock3 b = o3mu->Read(key);
	return b.values[0];
}

void OAR::Write(string key, ull d)
{
	if (m_bCompressed)
	{
		DataBlock3 V(2, 0);
		V.values[0] = d;
		V.values[1] = 0;		
		o3mu->Write(OPTYPE_ADD, key, V.values);
	}
	else
	{
		DataBlock3 V(4, 0);
		V.values[0] = d;
		V.values[1] = 1;
		V.values[2] = 0;
		V.values[3] = 0;
		o3mu->Write(OPTYPE_ADD, key, V.values);
	}
}

void OAR::Add(string key, ull d)
{
	if (m_bCompressed)
	{
		DataBlock3 V(2, 0);
		V.values[0] = 1;		
		V.values[1] = d;		
		o3mu->Write(OPTYPE_ADD, key, V.values);
	}
	else
	{
		DataBlock3 V(4, 0);
		V.values[0] = 1;
		V.values[1] = 0;
		V.values[2] = d;
		V.values[3] = 1;
		o3mu->Write(OPTYPE_ADD, key, V.values);
	}
}

void OAR::Mul(string key, ull d)
{
	if (m_bCompressed)
	{
		DataBlock3 V(2, 0);
		V.values[0] = d;
		V.values[1] = 0;
		o3mu->Write(OPTYPE_ADD, key, V.values);


	}
	else
	{
		DataBlock3 V(4, 0);
		V.values[0] = d;
		V.values[1] = 0;
		V.values[2] = 0;
		V.values[3] = 1;
		o3mu->Write(OPTYPE_ADD, key, V.values);
	}
}
