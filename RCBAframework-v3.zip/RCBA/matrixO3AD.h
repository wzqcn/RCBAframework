#pragma once
#include "RWtree.h"
class matrixO3AD
{
public:
	matrixO3AD(int height,int n); //n*n size matrix
	~matrixO3AD();
	vector<ull> Read(string key);
	void Write(string key, vector<ull> matrix);
	void Add(string key, vector<ull> matrix);
	RWtree *tree;
	int m_height;
	int m_n;
};

