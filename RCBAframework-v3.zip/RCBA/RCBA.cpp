#include "RCBA.h"
#include "RWtree.h"
#include "cassert"

RWtree* RCBA::owam = nullptr;
void RCBA::defaultInit(int treeHeight)
{
	if (RCBA::owam)
	{
		delete RCBA::owam;
		RCBA::owam = NULL;
	}
	RWtree* oad = new RWtree(treeHeight, 4, 1);
	oad->pPositionMap = GenPositionMap();
	//oad->User_Defined_Operation = myOperation;
	RCBA::owam = oad;
}
void RCBA::Init(int treeHeight,int u)
{
	if (RCBA::owam)
	{
		delete RCBA::owam;
		RCBA::owam = NULL;
	}
	RWtree* oad = new RWtree(treeHeight, 4, u);
	oad->pPositionMap = GenPositionMap();
	//oad->User_Defined_Operation = myOperation;
	RCBA::owam = oad;
}
DataBlock3 RCBA::read(string key, int c)
{
	//
	return owam->Read(key + ','+IntToStr(c));
}

DataBlock3 RCBA::copy(string key, int c, int r)
{
	//
	DataBlock3 b = owam->Read(key + ','+IntToStr(c));
	for (int i = 1; i <= r; i++)
	{
		owam->Write(OP_TYPE::OPTYPE_ASSIGN, key + ','+IntToStr(c + i), b.values);
	}
	return b;
}
void RCBA::write(string key, int c, OP_TYPE op, DataBlock3 v)
{
	//
	owam->Write(op, key + ','+IntToStr(c), v.values);
};

void testRCBA()
{
	RWtree* oad = new RWtree(10, 4, 1);
	oad->pPositionMap = GenPositionMap();
	RCBA::owam = oad;
	DataBlock3 b(1, 1);
	RCBA::write("test", 1, OP_TYPE::OPTYPE_ASSIGN, b);

	printf("0+1+...99=\n");
	for (int i = 0; i < 100; i++)
	{
		DataBlock3 b(1, i);
		oad->Write(OP_TYPE::OPTYPE_ADD, "test",b.values);

	}
	DataBlock3 result=oad->Read("test");
	result.print();
}

DataBlock3 myOperation(DataBlock3 b1, DataBlock3 b2)
{
	DataBlock3 b(2,0);
	assert(b1.values.size() == 2);
	assert(b2.values.size() == 2);
	//b = b1;
	b.values[0] = b2.values[0];
	b.values[1] += b1.values[1]+b2.values[1];
//	printf("(%lld %lld)  + (%lld %lld) => (%lld %lld)\n", b1.values[0], b1.values[1], b2.values[0], b2.values[1], b.values[0], b.values[1]);
	return b;
}
void TestOWC(int n)
{
	//int n = 100;
	RWtree* oad = new RWtree(20, 4, 2); // u=2
	oad->pPositionMap = GenPositionMap();
	oad->User_Defined_Operation = myOperation;
	RCBA::owam = oad;

	for (int i = 0; i < n; i++)
	{
		DataBlock3 b(2, 0);
		int s = rand32();
		if (s < 0) s = -s;
		int w = s%10;
		b.values[0] = w;
		b.values[1] = 1;
		RCBA::write(IntToStr(w), 0, OP_TYPE::OPTYPE_ADD, b);
	};

	for (int i = 0; i < n; i++)
	{
		DataBlock3 b = RCBA::read(IntToStr(i), 0);
		if (b.values.size() > 0)
		{
			printf("key=%lld count=%lld\n", b.values[0], b.values[1]);
		}
	}

}

