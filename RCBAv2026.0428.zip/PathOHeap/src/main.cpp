#include "Job.h"
#include "Job2.h"
#include "JobForStatisticalSimulation.h"
#include "PlainHeapComparisonTest.h"
#include "../OHeap.h"


void testBandwidthPerOperation()
{
	for (int i = 10; i < 11; i++)
	{
		printf("=================\r\n height=%d\r\n", i);
		OHeap h(i);

		Value b = ToValue(1);
		h.startCount();
		//	h.insertBlock(0, b);
		h.insertBlock(0, b);
		auto bk = h.extractMin();
		h.ShowReport();
	}
}
void testSortBandwdith()
{
	OHeap heap(1);
	vector<int> X, Y,Y1;
	for (int i = 10; i < 21; i++)
	{
		vector<int> ar = heap.randomArray(pow(2, 6));
		heap.sort(i,ar);

		printf("height=%d, sortBlocks: %d\r\n", i, heap.sortBlockCount);
		X.push_back(i);
		Y.push_back(heap.sortBlockPerElement);
		Y1.push_back(heap.sortBlockPerElementPerPath);

		printf("insertBandsPerPath: "); dumpArray(heap.insertBandsPerPath);
		printf("extractMinBandPerPath: "); dumpArray(heap.extractMinBandPerPath);
		printf("resultInsertBandsPerPath"); dumpArray(heap.resultInsertBandsPerPath);
	}
	printf("L= "); dumpArray(X);
	printf("Y1= "); dumpArray(Y1);
	printf("Figure 1: Y= "); dumpArray(Y);
	

}
void testDeduplicationBandwdith()
{
	OHeap heap(1);
	vector<int> X, Y, Y1;
	for (int i = 10; i < 21; i++)
	{
		vector<int> ar = heap.randomArray(pow(2, 10));
		vector<int> v;
		for (int i = 0; i < ar.size(); i++)
		{
			v.push_back(ar[i] % 64);
		}
		heap.deduplication(i, v);

		printf("height=%d, sortBlocks: %d\r\n", i, heap.sortBlockCount);
		X.push_back(i);
		Y.push_back(heap.sortBlockPerElement);
		Y1.push_back(heap.sortBlockPerElementPerPath);

		//printf("insertBandsPerPath: "); dumpArray(heap.insertBandsPerPath);
	//	printf("extractMinBandPerPath: "); dumpArray(heap.extractMinBandPerPath);
	//	printf("resultInsertBandsPerPath"); dumpArray(heap.resultInsertBandsPerPath);
	}
	printf("L= "); dumpArray(X);
	printf("Y1= "); dumpArray(Y1);
	printf("Figure 2 Deduplication: Y= "); dumpArray(Y);


}

int main() 
{
	//testBandwidthPerOperation(); 
	printf("press any key to test sorting bandwidth...\r\n");
	getchar();
	testSortBandwdith();
	printf("press any key to test deduplication bandwidth...\r\n");
	getchar();
	testDeduplicationBandwdith();

  //Job::run();
  //Job2::run();
  //JobForStatisticalSimulation::run();
//  PlainHeapComparisonTest().run();
}
