#ifndef POHEAP_UNTRUSTEDSTORAGEINTERFACE_H
#define POHEAP_UNTRUSTEDSTORAGEINTERFACE_H

#include "Bucket.h"
#include <unordered_map>

class UntrustedStorageInterface {
 public:
  virtual void setCapacity(int total_num_of_buckets) = 0;
  virtual Bucket readBucket(int position) = 0;
  virtual void writeBucket(int position, const Bucket& bucket_to_write) = 0;
  int num_read_bucket = 0;
  int num_write_bucket = 0;
  std::unordered_map<int, int> readCounter;
  std::unordered_map<int, int> writeCounter;
};

#endif
