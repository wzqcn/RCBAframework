#pragma once

#include "ServerStorage.h"
#include "RandomForOHeap.h"
#include "OHeapReadPathEviction.h"
#include <array>
#include <cstddef>
#include "Block.h"
using namespace std;

using Value = array<std::byte, Block::BLOCK_SIZE>;

Value ToValue(int i);
void dumpArray(vector<int> v);

class OHeap
{
public:
	OHeap(int height);
	int m_height = 0;
	int insert_Band = 0;
	int extractMin_Band = 0;
	int sortBlockCount = 0;
	int sortBlockPerElement = 0;
	int sortBlockPerElementPerPath = 0;
	vector<int> insertBandsPerPath;
	vector<int> extractMinBandPerPath;
	vector<int> resultInsertBandsPerPath;

	~OHeap();

	void insertBlock(int i, Value block);

	Block extractMin();

	void startCount();

	vector<int> randomArray(int size);

	OHeap sort(int tree_height,vector<int> arr);

	OHeap deduplication(int height, vector<int> arr);


	void ShowReport();

	void testBandwidthPerOperation();

	vector<int> sortBandwith;

	UntrustedStorageInterface* storage;
	RandForOHeapInterface* random;
	OHeapInterface* oheap;
};

