#include "OHeap.h"

OHeap::OHeap(int height)
{
	m_height = height;
	storage = new ServerStorage();
	random = new RandomForOHeap();
	oheap = new OHeapReadPathEviction(storage, random, 4, pow(2, height - 1), false);

}
OHeap::~OHeap()
{
	delete oheap;
	delete random;
	delete storage;
}

void OHeap::insertBlock(int i, Value v)
{
	storage->readCounter.clear();
	storage->writeCounter.clear();
	int c = storage->num_read_bucket;
	int w = storage->num_write_bucket;
	oheap->insertBlock(i, v);
	int c1 = storage->num_read_bucket;
	int w1 = storage->num_write_bucket;

	insert_Band = c1 - c + w1 - w;
}

Block OHeap::extractMin()
{
	storage->readCounter.clear();
	storage->writeCounter.clear();

	int c = storage->num_read_bucket;
	int w = storage->num_write_bucket;
	Block b = oheap->extractMin();
	int c1 = storage->num_read_bucket;
	int w1 = storage->num_write_bucket;
	extractMin_Band = c1 - c + w1 - w;
	return b;
}
void OHeap::startCount()
{
	storage->num_read_bucket = 0;
	storage->num_write_bucket = 0;
	storage->readCounter.clear();
	storage->writeCounter.clear();
}

vector<int> OHeap::randomArray(int size)
{
	std::random_device rd;                      // 
	std::mt19937 gen(rd());                     // 
	
	std::uniform_int_distribution<int> dist(0, size);

	
	std::vector<int> arr(size);
	for (int i = 0; i < size; ++i) 
	{
		arr[i] = dist(gen);
	}
	return arr;
}

OHeap OHeap::sort(int height,vector<int> arr)
{
	//int height = ceil(log2(arr.size()));
	int sortBandwidth = 0;
	OHeap input(height);
	OHeap output(height);
	sortBlockCount = 0;
	input.storage->num_read_bucket = 0;
	input.storage->num_write_bucket = 0;
	output.storage->num_read_bucket = 0;
	output.storage->num_write_bucket = 0;
	insertBandsPerPath.clear();
	extractMinBandPerPath.clear();
	resultInsertBandsPerPath.clear();

	for (int i = 0; i < arr.size(); i++)
	{
		Value v = ToValue(arr[i]);
		input.insertBlock(i, v); //Initialization
		insertBandsPerPath.push_back((float)input.insert_Band/height*5);// each bucket has 4 data blocks + 1 subtree-min block
	}
	for (int i = 0; i < arr.size(); i++)
	{
		Value v = ToValue(arr[i]);
		Block b= input.extractMin();	//sorting	
		extractMinBandPerPath.push_back((float)input.extractMin_Band / height*5);// each bucket has 4 data blocks + 1 subtree-min block

		output.insertBlock(i, b.v);		//result storage
		resultInsertBandsPerPath.push_back((float)output.insert_Band / height * 5);
	}
	// each bucket has 4 data blocks + 1 subtree-min block
	sortBlockCount = input.storage->num_read_bucket*5 + input.storage->num_write_bucket * 5+ output.storage->num_read_bucket * 5 + output.storage->num_write_bucket * 5;
	sortBlockPerElement = (float)sortBlockCount / arr.size();
	sortBlockPerElementPerPath = (float)sortBlockCount / arr.size() / height;
	return output;
}
OHeap OHeap::deduplication(int height, vector<int> arr)
{
	//int height = ceil(log2(arr.size()));
	int sortBandwidth = 0;
	OHeap input(height);
	OHeap output(height);
	sortBlockCount = 0;
	input.storage->num_read_bucket = 0;
	input.storage->num_write_bucket = 0;
	output.storage->num_read_bucket = 0;
	output.storage->num_write_bucket = 0;
	insertBandsPerPath.clear();
	extractMinBandPerPath.clear();
	resultInsertBandsPerPath.clear();

	for (int i = 0; i < arr.size(); i++)
	{
		Value v = ToValue(arr[i]);
		input.insertBlock(i, v); //Initialization
		insertBandsPerPath.push_back((float)input.insert_Band / height * 5);// each bucket has 4 data blocks + 1 subtree-min block
	}
	Block lastBlock;
	for (int i = 0; i < arr.size(); i++)
	{
		Value v = ToValue(arr[i]);
		Block b = input.extractMin();	//sorting

		if (b != lastBlock)
		{
			extractMinBandPerPath.push_back((float)input.extractMin_Band / height * 5);// each bucket has 4 data blocks + 1 subtree-min block
			output.insertBlock(i, b.v);		//result storage
			resultInsertBandsPerPath.push_back((float)output.insert_Band / height * 5);
			lastBlock = b;
		}
		else
		{
			printf("duplicated element. ");
		}
	}
	// each bucket has 4 data blocks + 1 subtree-min block
	sortBlockCount = input.storage->num_read_bucket * 5 + input.storage->num_write_bucket * 5 + output.storage->num_read_bucket * 5 + output.storage->num_write_bucket * 5;
	sortBlockPerElement = (float)sortBlockCount / arr.size();
	sortBlockPerElementPerPath = (float)sortBlockCount / arr.size() / height;
	return output;
}

void OHeap::ShowReport()
{
	//printf("insert bandwidth:%f (buckets per path) \r\n", (float)(insert_Band) / m_height);
	//printf("insert bandwidth:%f (blocks) \r\n", (float)(insert_Band) * 5); //4 +1 blocks
	printf("insert bandwidth:%f (blocks per path) \r\n", (float)(insert_Band) / m_height  *5); //4 +1 blocks
	//printf("extractMin bandwidth:%f (buckets per path) \r\n", (float)(extractMin_Band) / m_height);
	//printf("extractMin bandwidth:%f (blocks) \r\n", (float)(extractMin_Band)   * 5);
	printf("extractMin bandwidth:%f (blocks per path) \r\n", (float)(extractMin_Band) / m_height*5);
	printf("sort bandwidth:%f (blocks per path) \r\n", (float)(insert_Band*2+extractMin_Band) / m_height * 5);
}

void OHeap::testBandwidthPerOperation()
{
	for (int i = 10; i < 22; i++)
	{
		printf("=================\r\n height=%d\r\n", i);
		OHeap h(i);

		Value b = ToValue(1);
		h.startCount();
		//	h.insertBlock(0, b);
		h.insertBlock(0, b);
		auto bk = h.extractMin();
		h.ShowReport();
	}
}

Value ToValue(int i)
{
		std::array<std::byte, Block::BLOCK_SIZE> ret;		
		ret.fill(std::byte{ 0 });
		ret.at(0) = static_cast<std::byte>((i) & 0xFF);
		ret.at(1) = static_cast<std::byte>((i >> 8) & 0xFF);
		ret.at(2) = static_cast<std::byte>((i >> 16) & 0xFF);
		ret.at(3) = static_cast<std::byte>((i>>24) & 0xFF);
		return ret;
}
void dumpArray(vector<int> v)
{
	printf("[");
	int j = 0;
	for (auto i : v)
	{
		if (++j == v.size())
		{
			printf("%d ", i);
		}
		else
		{
			printf("%d, ", i);
		}
	}
	printf("]\r\n");
}

