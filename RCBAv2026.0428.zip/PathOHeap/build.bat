@echo off
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat" x64
cd /d e:\project\poh\PathOHeap
cl /std:c++17 /EHsc /I"src" /Fo"obj\\" /Fe"POHeapTester.exe" src\main.cpp src\Block.cpp src\Bucket.cpp src\Job.cpp src\Job2.cpp src\JobForStatisticalSimulation.cpp src\OHeapReadPathEviction.cpp src\PlainHeapComparisonTest.cpp src\RandomForOHeap.cpp src\ServerStorage.cpp
if %errorlevel% neq 0 pause