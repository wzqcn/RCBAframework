This is a revision of the Path Oblivious Heap from:
https://github.com/obliviousram/PathOHeap.

Modifications:
1) Support Windows 10;
2) Support Visual Studio 2026.
3) Add an implementation of oblivious sort and deduplication.
