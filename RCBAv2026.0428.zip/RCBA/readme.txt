RCBA framwork v2026.0428

It includes:

1) The implementation of RW-tree (RW-tree.cpp, RW-tree.h).

2) The implementation of RCBA framework (RCBA.cpp, RCBA.h).

3) The implementation of OAD (OAD.cpp, OAD.h).

4) The implementation of OMU (OMU.cpp, OMU.h).

5) The implementation of Matrix OAD (matrixO3AD.cpp, matrixO3AD.h).

6) The implementation of Matrix OMU (matrixO3MU.cpp, matrixO3MU.h).

7) The implementation of OAR and the compressed OAR (OAR.cpp, OAR.h).

8) The implementation of OB-array (OB-array.cpp, OB-array.h), 
   including OC-sort,OR-sort,oblivious deduplication,copy,merge,push,clear,reset and more.
9) All test cases (TestApp.cpp).

10) The visual studio 2026 project file (RCBAframework.sln). Install Windows 10 and Visual Studio 2026 first.

11) The source code of Figures \ref{f1}-\ref{f8}.

Figure \ref{f1}: the function Figure1_OC_sort_vs_POS().

Figure \ref{f2}: the function Figure2_Odedup_vs_POH().

Figure \ref{f3}: the function testOWC().

Figure \ref{f4}: the function testBandwidth().

Figure \ref{f5}: the function testObarrayBand().

Figure \ref{f6}: the function testMaxStashSize().

Figure \ref{f7}: the function testObarrayFunctions().

Figure \ref{f8}: the function testObarrayAccessTime().

12) A new implementation of PATH-ORAM (PATHORAM2.cpp, PATHORAM.h).

13) A binary file: RCBA.exe. Press 1 to 9 to perform the selected experiment.