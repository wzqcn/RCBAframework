﻿
#define _CRT_SECURE_NO_WARNINGS
#include "common.h"
#include <conio.h> //kbhit
#include <iostream>
#include <unordered_map>
#include "CPath64.h"
#include "myhash.h"
#include "myAES.h"
#include <vector>
#include <string>
#include "OAR.h"
#include "OMU.h"
#include "OAD.h"
#include "matrixO3AD.h"
#include "matrixO3MU.h"
#include "OMC.h"


using namespace std;


#include "PATHORAM.h"
#include <stdio.h>
#include <stdarg.h>


int printf2(const char* format, ...) 
{
	FILE* file = fopen("experiment.txt", "a+");
	va_list args;
	int console_chars, file_chars;

	va_start(args, format);
	console_chars = vprintf(format, args);
	va_end(args);


	va_start(args, format);
	file_chars = vfprintf(file, format, args);
	va_end(args);
	fclose(file);

	return console_chars;
}

void testPathORAM()
{
	int u = 4;
	PATHORAM oram(20,4,u);
	ull r=200,r2=0;

	vector<ull> testdata = { 100,200,300,400 };
	vector<ull> b2 = { 1,2,3,4 };
	vector<ull> b3 = {  };
	oram.Write("hello", testdata);
	
	for (int i = 0; i < 1000; i++)
	{
		b2[0] = i;
		oram.Write(IntToStr(i), b2);
		//oram.ShowReport();
		b3=oram.Read(IntToStr(i));
		if (b3.size() == 0 || b3[0] != i)
		{
			printf2("error!i=%d",i);
			getchar();
		}		
	};
	/**/
//	oram.Access("read", 100, 4, r2);
//	printf2("r=%lld \n", r2);

	auto testdata2 = oram.Read("hello");
	printf2(":\r\n");
	for(auto i: testdata2) std::cout << i<<"\n";
//	oram.ShowReport();
//	getchar();
}

void testPathORAM11()
{

	PATHORAM oram(20, 4, 4);
	ull r = 200, r2 = 0;

	vector<ull> testdata = { 100,200,300,400,1,1,1,1 };
	vector<ull> b2 = { 1,2,3,4,5,6,7,8 };
	vector<ull> b3 = {  };
	oram.Write("hello", testdata);
	printf("NumberOfInteractions per query:%d\n", oram.GetTotalNumberOfInteractions());

	for (int i = 0; i < 10000; i++)
	{
		b2[0] = i;
		oram.Write(IntToStr(i), b2);
		//oram.ShowReport();
		b3 = oram.Read(IntToStr(i));
		if (b3.size() == 0 || b3[0] != i)
		{
			printf2("error!i=%d", i);
			getchar();
		}
	};
	/**/
//	oram.Access("read", 100, 4, r2);
//	printf2("r=%lld \n", r2);

	auto testdata2 = oram.Read("hello");
	printf2(":\r\n");
	for (auto i : testdata2) std::cout << i << "\n";
	//	oram.ShowReport();
	//	getchar();
	printf("stash size:%lld\n", oram.GetStashSize());
}

void testPathORAM2()
{
	int u = 32;//
	int Z = 3;
	int L = 24;
	PATHORAM oram(L, Z, u);
	int c = pow(2, L) / 1000;
//	vector<ull> testdata = { 100,200,300,400 };
//	oram.Write("hello", testdata);
	double t1 = time_ms();
	for (int i = 0; i < c; i++)
	{
		vector<ull> data;
		for (int j = 0; j < u; j++)
		{
			data.push_back(j*i);
		}
		oram.Write(IntToStr(i), data);
	};
	double t2 = time_ms();
	printf2("u=%d Z=%d L=%d speed: %f (ms/per query)\r\n", u,Z,L,(t2 - t1) / c);
//	auto testdata2 = oram.Read(IntToStr(100));
//	for (auto i : testdata2) std::cout << i << "\n";
//	auto testdata3 = oram.Read("hello");
//	for (auto i : testdata3) std::cout << i << "\n";
	oram.ShowReport();
	getchar();
}

void test3(int u,int Z,int L)
{
	printf2("============================================================\r\n");
	printf2("u=%d Z=%lld L=%lld\r\n", u, Z, L);
	PATHORAM oram(L, Z, u);
	int c = pow(2, L) / 1000;
	
	double t1 = time_ms();
	for (int i = 0; i < c; i++)
	{
		vector<ull> data;
		for (int j = 0; j < u; j++)
		{
			data.push_back(j * i);
		}
		oram.Write(IntToStr(i), data);
	};
	double t2 = time_ms();
	printf2("u=%d Z=%d L=%d speed: %f (ms/per query) stash=%lld N=%lld\r\n", u, Z, L, (t2 - t1) / c,oram.GetStashSize(),oram.GetN());
	oram.ShowReport();
}

void testPathORAM3()
{
	//test3(32,4,20);
	for (int u = 1; u <= 32; u++)
	{
		for (int Z = 3; Z <= 5; Z++)
		{
			for (int L = 10; L <= 24; L++)
			{
				test3(u, Z, L);
			}
		}
	}	
}

#include "RWtree.h"
void testRWtree1()
{
	RWtree r(20, 4, 5);


	r.pPositionMap = GenPositionMap();
	DataBlock3 d(5, 100);
	DataBlock3 d2(5, 200);
	DataBlock3 d3(5, 400);
	DataBlock3 d4(5, 900);

//	r.Write(OP_TYPE::OPTYPE_ADD, "test", d3.values);
//	r.dump();
	//IndexKey3 ik1 = r.ToIndexKey3("test");

	for (int i = 0; i < 300; i++)
	{
		r.Write(OP_TYPE::OPTYPE_ASSIGN, "test", d.values);
	//r.dump();
	}
	for (int i = 0; i < 300; i++)
	{
		r.Write(OP_TYPE::OPTYPE_ASSIGN, "test2", d3.values);
	//	r.dump();
	}
	r.Write(OP_TYPE::OPTYPE_ASSIGN, "test", d2.values);
	r.dump();
	//for (int i = 0; i < 100; i++)	r.Write(OP_TYPE::OPTYPE_ASSIGN, "test3", d3.values);
//	DataBlock3 b2 = r.Read("test");
//	b2.print();
	r.Write(OP_TYPE::OPTYPE_ADD, "test", d4.values);
	printf2("\n read:");
	r.dump();
	IndexKey3 ik = r.ToIndexKey3("test");
	ik.print();
	DataBlock3 b3 = r.Read("test");//
	b3.print();
	r.dumpLevels();
	r.ShowReport();
}
void testRWtree2()
{
	RWtree r(20, 4, 5);
	r.pPositionMap = GenPositionMap();
	DataBlock3 d(5, 100);
	DataBlock3 d2(5, 400);
	DataBlock3 d3(5, 0);
	r.Write(OP_TYPE::OPTYPE_ASSIGN, "test", d.values);
	for (int i = 0; i < 100; i++)
	{
		d3.SetAll(i);
		r.Write(OP_TYPE::OPTYPE_ASSIGN, string("t")+IntToStr(i), d3.values);
		r.Write(OP_TYPE::OPTYPE_ADD, string("t") + IntToStr(i), d3.values);
	}
	for (int i = 0; i < 1000; i++)
	{
		d3.SetAll(i);
		r.Write(OP_TYPE::OPTYPE_ASSIGN, string("q") + IntToStr(i), d3.values);
	}
	for (int i = 0; i < 100; i++)
	{
		d3 = r.Read(string("t")+IntToStr(i));
		d3.print();
	}
	r.ShowReport();
}
void testOAR()
{
	OAR oar(20,false);
	oar.Write("test", 100);
	oar.Add("test", 200);
	oar.Mul("test", 300);
	ull r = oar.Read("test");
	printf2("OAR: (100+200)*300=%lld \n", r);

	OAR oar2(20, true);
	oar2.Write("test", 100);
	oar2.Add("test", 200);
	oar2.Mul("test", 400);
	ull r2 = oar2.Read("test");
	printf2("OAR: (100+200)*400=%lld \n", r2);
};

void testmatrixO3AD_O3MU()
{
	matrixO3AD o3ad(20,2);
	o3ad.Write("test", { 1,2,3,4 });
	o3ad.Add("test", { 5,6,7,8 });
	vector<ull> v = o3ad.Read("test");
	for(auto i:v) printf("%lld ",i);

	matrixO3MU o3mu(20,2);
	o3mu.Write("test", { 1,2,3,4 });
	o3mu.Mul ("test", { 1,1,1,1 });
	v = o3mu.Read("test");
	for (auto i : v) printf("%lld ", i);
}

#include "RCBA.h"
#include "OBarray.h"

void testObarray()
{
	RCBA::defaultInit(20);
	OBarray ob(100);
	DataBlock3 v(1, 1);
	DataBlock3 v2(1, 0);
	
	for (int i = 0; i < 100; i++)
	{
		v.values[0] = i;
		ob.write(i, OPTYPE_ADD, v);
	}
	for (int i = 0; i < 100; i++)
	{
		v = ob.read(i);
		if (v.values[0] != i)
		{
			printf2("error!%d,", i);
		}
	}
	for (int i = 0; i < 100; i++)
	{
		ob[i] = DataBlock3(1, i * 100);
	}
	for (int i = 0; i < 100; i++)
	{
		ob[i] += DataBlock3(1, 8);
	}
	for (int i = 0; i < 100; i++)
	{
		
		DataBlock3 v = ob[i];
		if (v.values.size() > 0)
		{
			printf("%d ", v.values[0]);
		}
	}

	OBarray ob2 = ob.copy();
	OBarray ob3(0);
	ob3.merge(ob);
	ob3.merge(ob2);

	ob.ShowReport();
	ob2.ShowReport();
	ob3.ShowReport();
	
	
}
void testObarraySort()
{
	RCBA::defaultInit(20);
	OBarray ob;
	//ob.insert({ 1,3,2,5,4,6,3,7,8,5,9,0 });
	ob.dump();
	ob.insert({ 3,2,1,3 });
	auto c = ob.copy();
	auto d = ob.copy();
	ob.merge(d);
	ob.merge(c);
	ob.sort();
	ob.dump();

	//ob.dump();
	//ob.sort();

	//printf("==============\r\n sorted:\r\n");  
	//ob.dump();

	//printf("==============\r\n deduplication:\r\n");
	//ob.deduplication();
	//ob.dump();
}
#include <vector>
#include <algorithm>  // for std::shuffle
#include <random>     // for std::random_device, std::mt19937
void testObarraySort2()
{
	RCBA::defaultInit(20);
	OBarray ob;
	//ob.insert({ 123,1,4,456,123,2,6,5,8,8,8,3,6,9 });
	vector<ull> v;
	for (int i = 0; i < 10; i++)
	{
		v.push_back(std::rand()%500);
		//v.push_back(i);
	}
	for (int i = 0; i < 10; i++)
	{
		v.push_back(std::rand()%500);
		//v.push_back(i);
	}
	std::random_device rd;
	std::mt19937 g(rd());
	std::shuffle(v.begin(),v.end(),g);

	ob.insert(v);
	ob.dump();
//	ob.radixSort();
	ob.sort();
	ob.dump();
}

void testObarrayFunctions()
{
	for (int L = 12; L <= 22; L+=3)
	{
		RCBA::defaultInit(L);
		int n = 100;
		OBarray ob;

		std::vector<unsigned long long> vec;
		vec.reserve(n);
		for (int i = 0; i < n; ++i) {
			vec.push_back(std::rand() % n); // 
		}
		ob.insert(vec);

		
		printf("start copy:\r\n");
		ull c1 = RCBA::owam->report.total_bandwidth;
		OBarray ob2 = ob.copy();
		ull c2 = RCBA::owam->report.total_bandwidth;
		printf2("OBarray.copy: bandwith %lld, bandwithPerElement=%lld ,L=%d,size=%d\r\n", c2 - c1, (c2-c1)/n,L,ob.m_n);
		;
		
		printf("start merge:\r\n");
		ull v3 = RCBA::owam->report.total_bandwidth;
		OBarray ob3;
		ob3.merge(ob2);
		ull v4 = RCBA::owam->report.total_bandwidth;
		printf2("OBarray.merge: bandwith %lld, bandwithPerElement=%lld L=%d size=%d\r\n", v4 - v3, (v4 - v3) / n, L, ob.m_n);
		
		printf("start sort:\r\n");
		ull v11 = RCBA::owam->report.total_bandwidth;
		ob.sort();
		ull v22 = RCBA::owam->report.total_bandwidth;
		printf2("OBarray.sort: bandwith %lld, bandwithPerElement=%lld L=%d size=%d\r\n", v22 - v11, (v22 - v11) / n,L, ob.m_n);

		printf("start deduplication:\r\n");
		ull v5 = RCBA::owam->report.total_bandwidth;
		ob.deduplication();
		ull v6 = RCBA::owam->report.total_bandwidth;
		printf2("OBarray.deduplication: bandwith %lld, bandwithPerElement=%lld L=%d size=%d\r\n", v6 - v5, (v6 - v5)/n,L,  ob.m_n);


	};

}

//--------------------------------------------------------------------------------
//TEST OSUM
void OSUM_PATHORAM(int height,int n)
{
	int u = 4;
	PATHORAM oram(height, 4, u);
	
	//initlization
	for (int i = 0; i < n; i++)
	{
		vector<ull> b2;
		b2.push_back(i);
		oram.Write(IntToStr(i),b2);
	}

	double t1 = time_ms();
	int sum = 0;
	for (int i = 0; i < n; i++)
	{
		sum += oram.Read(IntToStr(i))[0];				
	}
	vector<ull> b2;
	b2.push_back(sum);
	oram.Write(IntToStr(n), b2);
	double t2 = time_ms();
	printf2("OSUM: PATHORAM, time=%lf (ms), L=%d, n=%d round trips:%d\n",t2-t1,height,n,oram.GetTotalNumberOfInteractions());
}
void OSUM(int height, int n)
{
	RWtree* oad = new RWtree(height, 4, 1);
	oad->pPositionMap = GenPositionMap();
	RCBA::owam = oad;
	DataBlock3 b(1, 1);

	//initlization
	for (int i = 0; i < n; i++)
	{
		DataBlock3 b(1, 1);
		b.values[0]=i;
		oad->Write(OP_TYPE::OPTYPE_ASSIGN, IntToStr(i), b.values);
	}

	double t1 = time_ms();
	for (int i = 0; i < n; i++)
	{
		auto b=oad->Read(IntToStr(i));
		oad->Write(OP_TYPE::OPTYPE_ADD, IntToStr(n), b.values);
	}
	double t2 = time_ms();
	printf2("OAD: time=%lf (ms), L=%d, n=%d\n", t2 - t1, height, n);
	delete oad;
}

void testOSUM()
{
	for (int i = 12; i < 23; i++)
	{
		OSUM(i, 1000);
		OSUM(i, 4000);
    }
	for (int i = 12; i < 23; i++)
	{
		OSUM_PATHORAM(i, 1000);
		OSUM_PATHORAM(i, 4000);
	}
}
void testOAD_OMU()
{
	OAD o(20);
	o.Write("test", 100);
	auto v = o.Read("test");
	printf("%lld\n", v);
	o.Add("test", 200);
	v = o.Read("test");
	printf("%lld\n", v);
	o.Write("test", 0);
	int sum = 0;
	for (int j = 0; j < 100; j++)
	{
		o.Write(IntToStr(j), j * 2);
	}
	for (int i = 0; i < 100; i++)
	{
		o.Add("test", i);
		sum += i;
	}
	if (sum == o.Read("test"))
	{
		printf("test ok\r\n");
	}
	else
	{
		printf("test failure.\r\n");
	}

	OMU m(20);
	m.Write("test", 100);
	m.Mul("test", 10);
	v = m.Read("test");
	printf("%lld\n", v);
}
//-------------------------------------------------------------------------------
//TEST OWC

DataBlock3 myAddOperation(DataBlock3 b1, DataBlock3 b2)
{
	DataBlock3 b(2, 0);
	b.values[0] = b2.values[0];
	b.values[1] += b1.values[1] + b2.values[1];
	//	printf2("(%lld %lld)  + (%lld %lld) => (%lld %lld)\n", b1.values[0], b1.values[1], b2.values[0], b2.values[1], b.values[0], b.values[1]);
	return b;
}

void TestOWC_O3AD(int height,int n)
{
	//int n = 100;
	RWtree* o3ad = new RWtree(height, 4, 2);//
	o3ad->pPositionMap = GenPositionMap();
	o3ad->User_Defined_Operation = myAddOperation;
	RCBA::owam = o3ad;

	double t1 = time_ms();
	for (int i = 0; i < n; i++)
	{
		DataBlock3 b(2, 0);
		int s = rand64();
		if (s < 0) s = -s;
		int w = s % 10;
		b.values[0] = w;
		b.values[1] = 1;
		RCBA::write(IntToStr(w), 0, OP_TYPE::OPTYPE_ADD, b);
	};
	double t2 = time_ms();

	printf2("O3AD: time=%lf (ms), L=%d, n=%d\n", t2 - t1, height, n);

	for (int i = 0; i < n; i++)
	{
		DataBlock3 b = RCBA::read(IntToStr(i), 0);
		if (b.values.size() > 0)
		{
			//printf2("key=%lld count=%lld\n", b.values[0], b.values[1]);
		}
	}
	delete o3ad;
}

void TestOWC_PATHORAM(int height,int n)
{
	//int n = 100;
	PATHORAM oram(height, 4, 4);
	vector<ull> b2;

	/*
	* initlization
	*/
	for (int i = 0; i < n; i++)
	{
		vector<ull> b;
		int d = rand64()%10;
		b.push_back(d);	
		oram.Write(IntToStr(i), b);
	};

	double t1 = time_ms();
	for (int i = 0; i < n; i++)
	{
		vector<ull> b;
		//b.push_back(1);
		vector<ull> v=oram.Read(IntToStr(i));
		ull v0 = 0;
		if (v.size() > 0) v0 = v[0];
		string key = string("s") + IntToStr(v0);
		vector<ull> v2 = oram.Read(key);
		if (v2.size() > 0)
		{
			v2[0]++;
			oram.Write(key, v2);
		}
		else
		{
			v2.push_back(1);
			oram.Write(key,v2);
		}
	};
	double t2 = time_ms();

	printf2("OSUM: PATHORAM, time=%lf (ms), L=%d, n=%d roundtrips=%d\n", t2 - t1, height, n,oram.GetTotalNumberOfInteractions());

	for (int i = 0; i < 10; i++)
	{
		string key = string("s") + IntToStr(i);
		auto b =oram.Read(key);
		if (b.size() > 0)
		{
			//printf2("key=%d count=%lld\n",i, b[0]);
		}
	}

}
void testOWC()
{
	for (int i = 12; i < 23; i++)
	{
		TestOWC_O3AD(i, 1000);
		TestOWC_O3AD(i, 4000);
	}

	for (int i = 12; i < 23; i++)
	{
		TestOWC_PATHORAM(i, 1000);
		TestOWC_PATHORAM(i, 4000);
	}
}
//--------------------------------------------------------------------------------
// bandwidth of OAD
//OAD
//OAR
//OAR COMPRESSED
//PATHORAM

void testBandwidth1(int height,int n)
{
	RWtree* oad = new RWtree(height, 4, 1);//
	oad->pPositionMap = GenPositionMap();
	//o3ad->User_Defined_Operation = myAddOperation;
	
	for (int i = 0; i < n; i++)
	{
		vector<ull> v;
		v.push_back(i);
		oad->Write(OPTYPE_ASSIGN, IntToStr(i), v);
	};
	printf2("OAD bandwidth/query=%lld (byte), L=%d, n=%d\n", oad->report.bandwidth_per_query, height, n);
	delete oad;

}
void testBandwidth2(int height, int n)
{

	OAR* oar = new OAR(height, false);//uncompressed
	for (int i = 0; i < n; i++)
	{
		//vector<ull> v;
		//v.push_back(i);
		oar->Write(IntToStr(i), i);
	};

	printf2("OAR bandwidth/query=%lld (byte), L=%d, n=%d\n", oar->o3mu->report.bandwidth_per_query, height, n);
	delete oar;
}
void testBandwidth3(int height, int n)
{
	
	OAR* oar2 = new OAR(height, true);//compressed
	double t1 = time_ms();
	for (int i = 0; i < n; i++)
	{
		//vector<ull> v;
		//v.push_back(i);
		oar2->Write(IntToStr(i), i);
	};
	double t2 = time_ms();
	printf2("OAR2(compressed) bandwidth/query=%lld (byte), L=%d, n=%d\n", oar2->o3mu->report.bandwidth_per_query, height, n);
	delete oar2;


}
void testBandwidth4(int height, int n)
{
	PATHORAM oram(height, 4, 4);
	for (int i = 0; i < n; i++)
	{
		vector<ull> b2;
		b2.push_back(i);
		oram.Write(IntToStr(i), b2);
	}
	printf2("PATHORAM bandwidth/query=%d (byte), L=%d, n=%d\n", oram.GetBandwidth(), height, n);
}
void testBandwidth()
{
	for (int i = 12; i < 23; i++)
	{
		testBandwidth1(i, 2000);
	}
	for (int i = 12; i < 23; i++)
	{
		testBandwidth2(i, 2000);
	}
	for (int i = 12; i < 23; i++)
	{
		testBandwidth3(i, 2000);
	}
	for (int i = 12; i < 23; i++)
	{
		testBandwidth4(i, 2000);
	}

	//testBandwidth4(40, 2000);
}
//---------------------------------------------------------------------------------------------------------------------
void testTimeComsuptionOAD(int height, int n)
{
	RWtree* oad = new RWtree(height, 4, 1);//
	oad->pPositionMap = GenPositionMap();
	//o3ad->User_Defined_Operation = myAddOperation;
	double t1, t2;

	t1 = time_ms();
	for (int i = 0; i < n; i++)
	{
		vector<ull> v;
		v.push_back(i);
		oad->Write(OPTYPE_ASSIGN, IntToStr(i), v);
	};
	t2 = time_ms();
	printf2("OAD time/query=%f (ms), L=%d, n=%d\n",(t2-t1)/n, height, n);
	delete oad;
}
void testTimeComsuptionOAR(int height, int n)
{
	double t1, t2;
	OAR* oar = new OAR(height, false);//uncompressed
	t1 = time_ms();
	for (int i = 0; i < n; i++)
	{
		//vector<ull> v;
		//v.push_back(i);
		oar->Write(IntToStr(i), i);
	};
	t2 = time_ms();
	printf2("OAR time/query=%f (ms), L=%d, n=%d\n", (t2 - t1) / n, height, n);
	delete oar;
}
void testTimeComsuptionOAR2(int height, int n)
{
	double t1, t2;
	OAR* oar2 = new OAR(height, true);//compressed
	t1 = time_ms();
	for (int i = 0; i < n; i++)
	{
		//vector<ull> v;
		//v.push_back(i);
		oar2->Write(IntToStr(i), i);
	};
	t2 = time_ms();
	printf2("OAR2(compressed) time/query = %f(ms), L = %d, n = % d\n", (t2 - t1) / n, height, n);
	delete oar2;

}
void testTimeComsuptionPATHORAM(int height, int n)
{
	double t1, t2;
	PATHORAM oram(height, 4, 4);
	t1 = time_ms();
	for (int i = 0; i < n; i++)
	{
		vector<ull> b2;
		b2.push_back(i);
		oram.Write(IntToStr(i), b2);
	}
	t2 = time_ms();
	printf2("PATHORAM time/query=%f (ms), L=%d, n=%d\n", (t2 - t1) / n, height, n);
}

void testTimeComsuption()
{
	for (int i = 12; i < 23; i++)
	{
		testTimeComsuptionOAD(i, 1000);
	}
	for (int i = 12; i < 23; i++)
	{
		testTimeComsuptionOAR(i, 1000);
	}
	for (int i = 12; i < 23; i++)
	{
		testTimeComsuptionOAR2(i, 1000);
	}
	for (int i = 12; i < 23; i++)
	{
		testTimeComsuptionPATHORAM(i, 1000);
	}
}
//--------------------------------------------------------------------------------
//test bandwidth of OB-array

void testObarrayBandPATHORAM(int height)
{
	//small OB-array n=height
	int n = height;

	PATHORAM p(height, 4, 4);

	for (int i = 0; i < n; i++)
	{		
		vector<ull> b2 = { (ull)i };
		p.Write(IntToStr(i), b2);
	}
	printf2("PATHORAM bandwidth/query=%lld (byte), L=%d, n=%d\n", p.GetBandwidth(), height, n);
	//large OB-array
}
void testObarrayBandWrite(int height)
{
	//small OB-array n=height
	int n = height;
	OBarray ob(n);
	RCBA::defaultInit(height);

	for (int i = 0; i < n; i++)
	{
		DataBlock3 v;
		v.values.push_back(i);
		ob.write(i, OPTYPE_ASSIGN, v);
	}
	printf2("OBarray write bandwidth/query=%lld (byte), L=%d, n=%d\n", RCBA::owam->report.bandwidth_per_query, height, n);

	//large OB-array
}
void testObarrayBandRead(int height)
{
	//small OB-array n=height
	int n = height;
	OBarray ob(n);
	RCBA::defaultInit(height);

	ull b1 = RCBA::owam->report.total_bandwidth;
	for (int i = 0; i < n; i++)
	{
		DataBlock3 v;
		v.values.push_back(i);
		auto data = ob.read(i);
	}
	ull b2 = RCBA::owam->report.total_bandwidth;
	printf2("OBarray read bandwidth/query=%lld (byte), L=%d, n=%d\n", (b2 - b1) / n, height, n);

	//large OB-array
}

void testObarrayBand()
{
	for (int i = 12; i < 23; i++)
	{
		testObarrayBandWrite(i);
	}
	for (int i = 12; i < 23; i++)
	{
		testObarrayBandRead(i);
	}
	for (int i = 12; i < 23; i++)
	{
		testObarrayBandPATHORAM(i);
	}
}
//--------------------------------------------------------------------------------------------------------

bool check_esc_key() {
	if (_kbhit()) {  // 
		int ch = _getch();
		if (ch == 27) {  // 
			return true;
		}
	}
	return false;
}

#include <conio.h> 
void testMaxStashSize()
{
	

	int max = 0;
	printf("Please input Z=?");
	int z = 0;
	scanf("%d", &z);
	RWtree r(16, z, 1);
	//Max stash size needed
	r.pPositionMap = GenPositionMap();
	printf2("\nz=%d \nstart experiment, press ESC to exit...\n",z);
	for (int i = 0;; i++)
	{
		int j = i % r.m_capacity;
		vector<ull> v;
		v.push_back(j);
		r.Write(OPTYPE_ASSIGN, IntToStr(j), v);
		int s = r.GetStashSize();
		if (r.GetStashSize() > max)
		{
			printf2("i=%d stash size=%d max=%d lambda=%lf\n", i, s, max,log2(i));
			max = r.GetStashSize();
		}
		if (check_esc_key()) {
			printf2("\nESC detected，program exits\n");
			break;
		}
	}
	printf2("RWtree max stash size %d\n", r.report.max_stash_size);
}

void testObarrayReadTime(int height,int n)
{	
	OBarray ob(n);
	RCBA::defaultInit(height);
	
	DataBlock3 d;
	d.values = { 100 };
	for(int i=0;i<1000;i++)
	ob.write(i, OPTYPE_ASSIGN, d);

	
	double t1 = time_ms();
	ob.read(1);
	double t2 = time_ms();
	
	printf2("OBarray read time/query=%lf (ms), L=%d, n=%d\n", t2-t1, height, n);	
	delete RCBA::owam;
	RCBA::owam = NULL;

}
void testObarrayReadTime()
{
	printf("small array:\n");
	for (int i = 12; i < 23; i++)
	{
		testObarrayReadTime(i, i);//log N size
	}

	printf("tiny array:\n");
	for (int i = 12; i < 23; i++)//large
	{
		testObarrayReadTime(i, 1);
	}

	printf("large array:\n");
	for (int i = 12; i < 23; i++)//large
	{
		testObarrayReadTime(i, pow(2,i));
	}


}

void testPATHORAM_Access_Time(int height)
{
	PATHORAM p(height, 4, 4);

	
	for (int i = 0; i < 1000; i++)
		p.Write(IntToStr(i), { 100 });


	double t1 = time_ms();
	p.Read("1");
	double t2 = time_ms();

	printf2("PATHORAM access time/query=%lf (ms), L=%d\n", t2 - t1, height);
	delete RCBA::owam;
	RCBA::owam = NULL;

}


void testObarrayAccessTime(int height, int n)
{
	OBarray ob(n);
	RCBA::defaultInit(height);

	DataBlock3 d;
	for (int i = 0; i < 1000; i++)
		ob.write(i, OPTYPE_ASSIGN, d);

	DataBlock3 v;
	v.values.push_back(1);
	double t1 = time_ms();
	ob.write(1, OPTYPE_ASSIGN, v);
	double t2 = time_ms();

	printf2("OBarray access time/query=%lf (ms), L=%d, n=%d\n", t2 - t1, height, n);
}

void testObarrayAccessTime()
{
	for (int i = 12; i < 23; i++)
	{
		testObarrayAccessTime(i, 32);
	}
	for (int i = 12; i < 23; i++)
	{
		testPATHORAM_Access_Time(i);
	}
}

void testOBarrayFunctions()
{

	RCBA::defaultInit(20);
	OBarray ob;
	vector<ull> v;
	for (int i = 0; i < 1000; i++)
	{
		v.push_back(i%100);
	}
	std::random_device rd;
	std::mt19937 g(rd());
	std::shuffle(v.begin(), v.end(), g);

	ob.insert(v);
	ob.dump();
	ob.radixSort();
	ob.dump();

}
void showCopy()
{
	printf("\r\n OBarray ob2=ob.copy();ob2.dump(); \r\n");
	getchar();
	RCBA::defaultInit(20);
	OBarray ob;
	vector<ull> v;
	for (int i = 0; i < 1000; i++)
	{
		v.push_back(i % 100);
	}
	ob.insert(v);
	OBarray ob2=ob.copy();
	ob2.dump();
}
void showMerge()
{
	printf("\r\n OBarray ob2=ob.merge(ob);ob2.dump(); \r\n");
	getchar();
	RCBA::defaultInit(20);
	OBarray ob,ob2;
	vector<ull> v;
	for (int i = 0; i < 500; i++)
	{
		v.push_back(i % 500);
	}
	ob.insert(v);
	for (int i = 0; i < 500; i++)
	{
		v.push_back(i % 500);
	}
	ob2.insert(v);
	ob2.merge(ob);
	ob2.dump();
}
void countingSort()
{
	printf("\r\n Oblivious Counting Sort (OC-sort);\r\n usage:\r\n ob.sort();\r\n");
	getchar();

	RCBA::defaultInit(20);
	OBarray ob, ob2;
	vector<ull> v;
	for (int i = 0; i < 1000; i++)
	{
		v.push_back(std::rand() % 500);
	}
	ob.insert(v);
	ob.sort();
	ob.dump();
}
void radixSort()
{
	printf("\r\n Oblivious Radix Sort (OR-sort)\r\n usage:\r\n ob.radixSort();\r\n");
	getchar();

	RCBA::defaultInit(20);
	OBarray ob, ob2;
	vector<ull> v;
	for (int i = 0; i < 1000; i++)
	{
		v.push_back(std::rand() % 500);
	}
	ob.insert(v);
	ob.radixSort();
	ob.dump();
}
void dumpArray(vector<ull> v)
{
	printf("[");
	ull j = 0;
	for (auto i : v)
	{
		if (++j == v.size())
		{
			printf("%d ", i);
		}
		else
		{
			printf("%d, ", i);
		}
	}
	printf("]\r\n");
}

void Figure1_OC_sort_vs_POS()
{
	vector<ull> X, Y;
	for (int i = 10; i < 21; i++)
	{
		RCBA::defaultInit(i);
		OBarray ob;
		int size = pow(2, 6);
		vector<ull> v;
		for (int i = 0; i < size; i++)
		{
			v.push_back(std::rand() % size);
		}
		ull b1=RCBA::owam->report.total_bandwidth_blocks;
		ob.insert(v);
		ob.sort();
		ull b2 = RCBA::owam->report.total_bandwidth_blocks;
		X.push_back(i);
		Y.push_back((float)(b2 - b1) / size);
	}
	printf("L= "); dumpArray(X);
	printf("the number of blocks per element for sorting:\r\n");
	printf("Figure 1 (OC-sort): Y= "); dumpArray(Y);
}

void Figure2_Odedup_vs_POH()
{
	vector<ull> X, Y;
	for (int i = 10; i < 21; i++)
	{
		RCBA::defaultInit(i);
		OBarray ob;
		int size = pow(2, 10);
		vector<ull> v;
		for (int i = 0; i < size; i++)
		{
			v.push_back(std::rand() % 64);
		}
		ull b1 = RCBA::owam->report.total_bandwidth_blocks;
		ob.insert(v);
		ob.deduplication();
		ull b2 = RCBA::owam->report.total_bandwidth_blocks;
		X.push_back(i);
		Y.push_back((float)(b2 - b1) / size);
	}
	printf("L= "); dumpArray(X);
	printf("Figure2(O-dedup): Y= "); dumpArray(Y);
}
void deduplication()
{
	printf("\r\n Oblivious Deduplication (OD)\r\n usage:\r\n ob.deduplication();\r\n");
	getchar();

	RCBA::defaultInit(20);
	OBarray ob;
	vector<ull> v;
	for (int i = 0; i < 1000; i++)
	{
		v.push_back(std::rand() % 10);
	}
	ob.insert(v);
	ob.deduplication();
	ob.dump();
}
void ShowOBarrayExamples()
{
	showCopy();
	showMerge();
	countingSort();
	radixSort();
	deduplication();
}

void ShowHelp()
{	
	printf("RCBA framework v2026.0428:\n\n");
	printf("1. Paper figure(a) OC-sort vs. POS \n");
	printf("2. Paper figure(b) O-dedup vs. POH \n");
	printf("3. Paper figure(c) oblivious word counting \n");
	printf("4. Paper figure(d) bandwidth of OWAMs \n");	
	printf("5. Paper figure(e) bandwidth of OB-array \n");
	printf("6. Paper figure(f) max stash size of OB-array\n");
	printf("7. Paper figure(g) functions of OB-array \n");
	printf("8. Paper figure(h) access time of OB-array \n");
	printf("9. OB-array examples \n");
	printf("please input [1-9]:\n");
}
void ProgramStart(int argc, char* argv[])
{

	while (1)
	{
		ShowHelp();
		//char buf[32] = { 0 };
		//sscanf(buf, "%c");
		char c;
		scanf("%c", &c);
		switch (c)
		{
		case '1':Figure1_OC_sort_vs_POS(); break;
		//case '2':simulateOMC(); break;
		case '2':Figure2_Odedup_vs_POH(); break;
		case '3':testOWC(); break;
		case '4':testBandwidth(); break;
		case '5':testObarrayBand(); break;
		case '6':testMaxStashSize(); break;
		case '7':testObarrayFunctions(); break;
		case '8':testObarrayAccessTime(); break;
		case '9':
		{
			ShowOBarrayExamples();
			break;
		}
		}
	}
}

#include "osam.h"
#include <cassert>
void testOSAM()
{
	SAM::OSAM osam(16, 4, 1);
	for (ull i = 0; i < 1000; i++)
	{
		vector<ull> v = { i };
		osam.Write(IntToStr(i), v);
	}
	osam.ShowReport();
	for (ull i = 0; i < 1000; i++)
	{
		ull j = osam.Read(IntToStr(i)).values[0];
		assert(j == i);
	}
}
int main(int c,char* argv[])
{
//	testPathORAM11();
//	testOAD_OMU();
//	testmatrixO3AD_O3MU();
//	testOSUM();
//	testOWC();
// 	testBandwidth();
//	testTimeComsuption();
//	testObarrayBand();
//	testMaxStashSize();
//	testObarrayReadTime();
//	testObarrayWriteTime();
//	testObarray();
//	testObarraySort();
//	testObarraySort2();
//	testOMC();
	//simulateOMC();//Figure (a)
	//simulateOMCStorage();//Figure (b)
	//testObarrayFunctions();
	ProgramStart(c, argv);
	//testOSAM();



}


