﻿#include <vector>
#include <iostream>
#include <cassert>
#include <cmath>
#include "OMC.h"

using namespace std;



// Statistics structure
struct OperationStats {
    long long readA;         // Read operations on matrix A
    long long readB;         // Read operations on matrix B
    long long writeAexp;     // Write operations on A_exp
    long long readAexp;      // Read operations on A_exp
    long long writeBexp;     // Write operations on B_exp
    long long readBexp;      // Read operations on B_exp
    long long writeT;        // Write operations on matrix T
    long long readT;         // Read operations on matrix T
    long long writeC;        // Write operations on matrix C

    void print() const {
        cout << "Operation Statistics:" << endl;
        cout << "Read A: " << readA << endl;
        cout << "Read B: " << readB << endl;
        cout << "Write A_exp: " << writeAexp << endl;
        cout << "Read A_exp: " << readAexp << endl;
        cout << "Write B_exp: " << writeBexp << endl;
        cout << "Read B_exp: " << readBexp << endl;
        cout << "Write T: " << writeT << endl;
        cout << "Read T: " << readT << endl;
        cout << "Write C: " << writeC << endl;
        cout << "Total operations: " << readA + readB + writeAexp + readAexp +
            writeBexp + readBexp + writeT + readT + writeC << endl;
    }
    long long GetTotal()
    {
        return readA + readB + writeAexp + readAexp + writeBexp + readBexp + writeT + readT + writeC;
    }
};


// R1W1 Matrix Multiplication Algorithm
vector<vector<double>> MultiplySingleAccess(const vector<vector<double>>& A,
    const vector<vector<double>>& B,
    OperationStats& stats) {

    // Reset statistics
    stats = OperationStats{ 0, 0, 0, 0, 0, 0, 0, 0, 0 };

    int n = A.size();
    assert(n > 0 && B.size() == n && B[0].size() == n);

    // Step 1: Create expanded copies A_exp and B_exp
    cout << "Creating expanded A and B copies..." << endl;

    // A_exp: n matrices, each n x n
    vector<vector<vector<double>>> A_exp(n, vector<vector<double>>(n, vector<double>(n, 0.0)));
    // B_exp: n matrices, each n x n  
    vector<vector<vector<double>>> B_exp(n, vector<vector<double>>(n, vector<double>(n, 0.0)));

    // Construct A_exp[k][i][j] = A[i][k]
    for (int k = 0; k < n; ++k) {
        for (int i = 0; i < n; ++i) {
            double a_val = A[i][k];
            stats.readA++;  // Each A[i][k] read once

            // Copy to all j positions
            for (int j = 0; j < n; ++j) {
                A_exp[k][i][j] = a_val;
                stats.writeAexp++;  // Each A_exp[k][i][j] written once
            }
        }
    }

    // Construct B_exp[k][i][j] = B[k][j]
    for (int k = 0; k < n; ++k) {
        for (int j = 0; j < n; ++j) {
            double b_val = B[k][j];
            stats.readB++;  // Each B[k][j] read once

            // Copy to all i positions
            for (int i = 0; i < n; ++i) {
                B_exp[k][i][j] = b_val;
                stats.writeBexp++;  // Each B_exp[k][i][j] written once
            }
        }
    }

    // Step 2: Compute outer product matrices T
    cout << "Computing outer product matrices T..." << endl;
    vector<vector<vector<double>>> T(n, vector<vector<double>>(n, vector<double>(n, 0.0)));

    for (int k = 0; k < n; ++k) {
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                // Read A_exp and B_exp each once, write T once
                double a = A_exp[k][i][j];
                double b = B_exp[k][i][j];
                stats.readAexp++;  // Each A_exp element read once
                stats.readBexp++;  // Each B_exp element read once

                T[k][i][j] = a * b;
                stats.writeT++;  // Each T element written once
            }
        }
    }

    // Step 3: Accumulate results to get C
    cout << "Accumulating T matrices to get C..." << endl;
    vector<vector<double>> C(n, vector<double>(n, 0.0));

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            double sum = 0.0;
            // Read each T[k][i][j] once
            for (int k = 0; k < n; ++k) {
                sum += T[k][i][j];
                stats.readT++;  // Each T element read once
            }
            C[i][j] = sum;
            stats.writeC++;  // Each C element written once
        }
    }

    return C;
}




// R1W∞ Matrix Multiplication Algorithm
vector<vector<double>> MultiplyWriteAccess(const vector<vector<double>>& A,
    const vector<vector<double>>& B,
    OperationStats& stats) {

    // Reset statistics
    stats = OperationStats{ 0, 0, 0, 0, 0 };

    int n = A.size();
    assert(n > 0 && B.size() == n && B[0].size() == n);

    // Initialize result matrix C with zeros
    vector<vector<double>> C(n, vector<double>(n, 0.0));

    // Main algorithm
    for (int k = 0; k < n; ++k) {
        // Step 1: Create B_exp[i,j] = B[k,j] for all i,j
        vector<vector<double>> B_exp(n, vector<double>(n, 0.0));

        // Fill B_exp: each B[k][j] is read once, each B_exp[i][j] is written once
        for (int j = 0; j < n; ++j) {
            double b_val = B[k][j];
            stats.readB++;  // Each B[k][j] read once

            // Copy to all rows i
            for (int i = 0; i < n; ++i) {
                B_exp[i][j] = b_val;
                stats.writeBexp++;  // Each B_exp[i][j] written once
            }
        }

        // Step 2: Compute contributions to C
        for (int i = 0; i < n; ++i) {
            double a = A[i][k];
            stats.readA++;  // Each A[i][k] read once

            for (int j = 0; j < n; ++j) {
                // Compute and accumulate: each B_exp[i][j] read once, C[i][j] written (via +=)
                C[i][j] += a * B_exp[i][j];
                stats.readBexp++;  // Each B_exp[i][j] read once
                stats.writeC++;    // Each += operation counts as a write to C
            }
        }
    }

    return C;
}

#include <unordered_map>
#include <string>
using namespace std;
unordered_map<std::string, double> cache;
double ReadAndCopy(string name,const vector<vector<double>>&m,int i,int j,int c)
{
    //
    if (c == 0)
    {
        double v = m[i][j];
        //string k = name+","+std::to_string(i) + std::to_string(j) + std::to_string(c);
        string k1 = name + "," + std::to_string(i) + "," + std::to_string(j) + "," + std::to_string(c+1);
        cache[k1] = v;
        return v;
    }

    double v=0;
    string k = name + "," + std::to_string(i) + "," + std::to_string(j) + "," + std::to_string(c);
    string k1 = name + "," + std::to_string(i) + "," + std::to_string(j) + "," + std::to_string(c + 1);
    v = cache[k];
    cache.erase(k);
    cache[k1] = v;

    return v;
}
void CopyAndWrite(string name, const vector<vector<double>>& m, int i, int j, int c,double data)
{
    //
    if (c == 0)
    {
        double v = m[i][j];
        //string k = name+","+std::to_string(i) + std::to_string(j) + std::to_string(c);
        string k1 = name + "," + std::to_string(i) + "," + std::to_string(j) + "," + std::to_string(c + 1);
        cache[k1] = v+data;
        return;
    }

    double v = 0;
    string k = name + "," + std::to_string(i) + "," + std::to_string(j) + "," + std::to_string(c);
    string k1 = name + "," + std::to_string(i) + "," + std::to_string(j) + "," + std::to_string(c + 1);
    v = cache[k];
    cache.erase(k);
    cache[k1] = v+data;

    return ;
}

// n^2 copy operaton
vector<vector<double>> GetCMatrixFromCache(const string& name, int n) {
    vector<vector<double>> C(n, vector<double>(n, 0.0));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) 
        {
            //  key = name + "," + i + "," + j + "," + n
            string key = name + "," + to_string(i) + "," + to_string(j) + "," + to_string(n);
            auto it = cache.find(key);
            if (it != cache.end()) {
                C[i][j] = it->second;
            }
        }
    }
    return C;
}

// Optimized algorithm (no temporary matrix T)
//R1W∞ accesses 3*n^3 paths 
vector<vector<double>> MultiplyOMC(const vector<vector<double>>& A,
    const vector<vector<double>>& B,
    OperationStats& stats) 
{
    // Reset statistics
    stats = OperationStats{ 0, 0, 0, 0, 0  };

    int n = A.size();
    assert(n > 0 && B.size() == n && B[0].size() == n);

    vector<vector<double>> C(n, vector<double>(n, 0.0));

    for (int k = 0; k < n; ++k) 
    {
        for (int i = 0; i < n; ++i) 
        {            
            for (int j = 0; j < n; ++j) 
            {
                double a = ReadAndCopy("A",A,i,k,j);
                stats.readA++;  // Read A[i][k]

                double b = ReadAndCopy("B", B, k, j, i); 
                stats.readB++;  // Read B[k][j]

                C[i][j] += a * b;//allow duplicated accesses
                stats.writeC++; // Write C[i][j]
            }
        }
    }

    return C;
}

//OSAM supports this algorithm
//R1W1 accesses 3*n^3 paths + n^2 paths
vector<vector<double>> MultiplyR1W1(const vector<vector<double>>& A,
    const vector<vector<double>>& B,
    OperationStats& stats)
{
    // Reset statistics
    stats = OperationStats{ 0, 0, 0, 0, 0 };

    int n = A.size();
    assert(n > 0 && B.size() == n && B[0].size() == n);

    vector<vector<double>> C(n, vector<double>(n, 0.0));

    for (int k = 0; k < n; ++k) 
    {
        for (int i = 0; i < n; ++i)
        {
            for (int j = 0; j < n; ++j)
            {
                double a = ReadAndCopy("A", A, i, k, j);
                stats.readA+=1;  // Read A[i][k]

                double b = ReadAndCopy("B", B, k, j, i);
                stats.readB+=1;  // Read B[k][j]

                //C[i][j] += a * b;
                CopyAndWrite("C",C,i,j,k,a*b);//avoid duplicated accessing to C[i,j]
                stats.writeC+=1; // Write C[i][j] read+write
            }
        }
    }    
    return GetCMatrixFromCache("C", n);
}


// Standard ijk-order matrix multiplication (for comparison)
vector<vector<double>> StandardMatrixMultiply(const vector<vector<double>>& A,
    const vector<vector<double>>& B,
    OperationStats& stats) {
    // Reset statistics
    stats = OperationStats{ 0, 0, 0, 0, 0  };

    int n = A.size();
    assert(n > 0 && B.size() == n && B[0].size() == n);

    vector<vector<double>> C(n, vector<double>(n, 0.0));

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            double sum = 0.0;
            for (int k = 0; k < n; ++k) {
                stats.readA++;  // Read A[i][k]
                stats.readB++;  // Read B[k][j]
                sum += A[i][k] * B[k][j];
            }
            C[i][j] = sum;
            stats.writeC++;  // Write C[i][j]
        }
    }
    return C;
}

void print(vector<vector<double>> C)
{
    for (vector<double> i : C)
    {
        printf("\r\n");
        for (double j : i)
        {
            printf("%lf ", j);
        }
    }
}

// Test function
int testOMC() {
    // Example matrices
    // Formula summary
    int n = 3;
    vector<vector<double>> A = { {1, 0, 0},
                               {0, 1,0},
                               {0, 0, 1} };

    vector<vector<double>> B = { {2, 2, 2},
                               {2, 2, 2},
                               {2, 2, 2} };

    OperationStats stats;

//    cout << "=== MultiplySingleAccess Algorithm ===" << endl;
//    vector<vector<double>> C1 = MultiplySingleAccess(A, B, stats);
//    stats.print();
//    print(C1);
//    cout << endl;

//    cout << "=== MultiplyWriteAccess Algorithm (with temporary matrix T) ===" << endl;
//    vector<vector<double>> C2 = MultiplyWriteAccess(A, B, stats);
//    stats.print();
//    print(C2);
//    cout << endl;


    cout << "=== R1W∞ MultiplyOMC Algorithm  ===" << endl;
    vector<vector<double>> C3 = MultiplyOMC(A, B, stats);
    stats.print();
    print(C3);

    cout << "=== R1W1 MultiplyOSAM Algorithm === " << endl;
    vector<vector<double>> C4 = MultiplyR1W1(A, B, stats);
    stats.print();
    print(C4);


//    cout << "=== Standard ijk-order Matrix Multiplication ===" << endl;
//    vector<vector<double>> C5 = StandardMatrixMultiply(A, B, stats);
//    stats.print();
//    print(C5);
    cout << endl;

    return 0;
}
void simulateOMC()
{
    OperationStats s1,s2,s3,s4;
    for (int i = 1; i <= 5; i++)
    {

        const vector<vector<double>> A(100*i, vector<double>(100*i, 1));
        const vector<vector<double>> B(100*i, vector<double>(100*i, 2));
       // auto C1 = MultiplySingleAccess(A, B, s1);
       // auto C2 = MultiplyWriteAccess(A, B, s2);
        auto C3 = MultiplyOMC(A, B, s3);
        auto C4 = MultiplyR1W1(A, B, s4);

        printf2("\r\n n=%d -----------------------------------\r\n", i*100);
        printf2("ORAM invocation: singeAccess=%lld WriteAccess=%lld OMC=%lld \n",s1.GetTotal(), s2.GetTotal(), s3.GetTotal());
    }
}

// 
string formatStorage(unsigned long long bytes) {
    const char* units[] = { "B", "KB", "MB", "GB", "TB", "PB" };
    int unitIndex = 0;
    double size = static_cast<double>(bytes);

    while (size >= 1024.0 && unitIndex < 5) {
        size /= 1024.0;
        unitIndex++;
    }

    char buffer[50];
    if (unitIndex == 0) {
        snprintf(buffer, sizeof(buffer), "%llu %s", bytes, units[unitIndex]);
    }
    else {
        snprintf(buffer, sizeof(buffer), "%.2f %s", size, units[unitIndex]);
    }

    return string(buffer);
}

void simulateOMCStorage()
{
    vector<unsigned long long > storage = { 100,500,1000,2000,5000 };
    for (unsigned long long  n:storage)
    {
      //  printf2("server storage,n=%d: singeAccess=%lld(byte) WriteAccess=%lld(byte) OMC=%lld(byte) \n", n,(3*n*n*n+3*n*n)*32, 4*n*n*32,3*n*n*32);
        unsigned long long singleAccessBytes = (3ULL * n * n * n + 3ULL * n * n) * 32ULL;
        unsigned long long writeAccessBytes = 4ULL * n * n * 32ULL;
        unsigned long long omcBytes = 3ULL * n * n * 32ULL;

        // 格式化为易读的字符串
        string singleAccessStr = formatStorage(singleAccessBytes);
        string writeAccessStr = formatStorage(writeAccessBytes);
        string omcStr = formatStorage(omcBytes);

        cout << "n=" << n << " (" << n << "×" << n << " matrix):" << endl;
        cout << "  MultiplySingleAccess: " << singleAccessStr << " ("<< singleAccessBytes<<")"<<endl;
        cout << "  MultiplyWriteAccess:  " << writeAccessStr << " (" << writeAccessBytes << ")" << endl;
        cout << "  MultiplyOMC:          " << omcStr << " (" << omcBytes << ")"<<endl;
        cout << endl;
    }
}