#pragma once

#include "common.h"
#include "CPath64.h"
#include "myhash.h"
#include "myAES.h"
#include <vector>
#include <algorithm>
#include <string>
#include <unordered_map>  // �Ȱ�����Ҫ��ͷ�ļ�

namespace SAM
{
#define ull unsigned long long
#define DUMMY_VALUE 888888888888

    // ǰ������
    struct IndexKey3;

    // �Զ���Hash�������Ƽ�ʹ�ã�����std::hash�ػ����⣩
    struct HashFunc3 {
        size_t operator()(const IndexKey3& key) const;
    };

    // ��ȱȽϺ���
    struct cmp_fun3 {
        bool operator()(const IndexKey3& a1, const IndexKey3& a2) const;
    };

    // �ȶ��� IndexKey3
    struct IndexKey3
    {
        unsigned char buf[8];

        bool operator==(const IndexKey3& other) const
        {
            return memcmp(buf, other.buf, sizeof(IndexKey3)) == 0;
        }

        void print()
        {
            printf("\n(");
            for (int i = 0; i < 4; i++)
            {
                printf("%.2x,", buf[i]);
            }
            printf("..)");
        }
    };

    // ʵ��HashFunc3
    inline size_t HashFunc3::operator()(const IndexKey3& key) const {
        size_t hash = 0;
        for (size_t i = 0; i < sizeof(key.buf); ++i) {
            hash = hash * 131 + key.buf[i];
        }
        return hash;
    }

    // ʵ��cmp_fun3
    inline bool cmp_fun3::operator()(const IndexKey3& a1, const IndexKey3& a2) const {
        return memcmp(a1.buf, a2.buf, sizeof(a1)) == 0;
    }

    struct ENode3
    {
        std::vector<unsigned char> bytes;
        int level;
        std::string path;
    };

    // ʹ���Զ���Hash��unordered_map
    typedef std::unordered_map<std::string, ENode3> ENodes3;

    struct DataBlock3
    {
        std::vector<ull> values;

        DataBlock3() {}

        DataBlock3(int u, int v)
        {
            Init(u);
            SetAll(v);
        }

        void Init(int u)
        {
            values.clear();
            for (int i = 0; i < u; i++)
            {
                values.push_back(DUMMY_VALUE);
            }
        }

        void SetAll(ull v)
        {
            for (size_t i = 0; i < values.size(); i++)
            {
                values[i] = v;
            }
        }

        void SetEmpty()
        {
            for (size_t i = 0; i < values.size(); i++)
            {
                values[i] = DUMMY_VALUE;
            }
        }

        bool isEmpty()
        {
            for (auto i : values)
            {
                if (i != DUMMY_VALUE) return false;
            }
            return true;
        }

        void print()
        {
            printf("\n(");
            for (auto i : values)
            {
                if (i == DUMMY_VALUE) printf(",");
                else
                    printf("%lld,", i);
            }
            printf(")");
        }
    };

    struct Slot3
    {
        IndexKey3 key;
        DataBlock3 value;
        BYTE bOP; //0 

        void GenEmptySlot(int u)
        {
            memset(&key, 0, sizeof(key));
            value.values.clear();
            for (int i = 0; i < u; i++)
            {
                value.values.push_back(DUMMY_VALUE);
            }
        }

        bool isEmpty()
        {
            for (auto i : value.values)
            {
                if (i != DUMMY_VALUE) return false;
            }
            return true;
        }
    };

    struct StashItem
    {
        IndexKey3 key;
        DataBlock3 value;
        int level;
        ull bOP;

        bool operator<(const StashItem& other) const
        {
            return level > other.level;
        }

        Slot3 ToSlot3()
        {
            Slot3 sl;
            sl.key = key;
            sl.value = value;
            sl.bOP = bOP;
            return sl;
        }
    };

    struct TreeNode3
    {
        std::vector<Slot3> slots;
        int level;
        std::string path;

        void GenEmptyNode(int Z, int u)
        {
            DataBlock3 db;
            Slot3 sl;
            sl.key = { 0 };
            db.values.clear();
            for (int i = 0; i < u; i++) db.values.push_back(DUMMY_VALUE);
            sl.value = db;
            slots.clear();
            for (int i = 0; i < Z; i++)
            {
                slots.push_back(sl);
            }
        }

        bool isEmpty()
        {
            for (auto s : slots)
            {
                if (!s.isEmpty()) return false;
            }
            return true;
        }
    };

    // ʹ���Զ���Hash��unordered_map
    typedef std::unordered_map<std::string, TreeNode3*> TreeNodes3;

    // ���һ��Ҫʹ��IndexKey3��Ϊkey��unordered_map��ʹ���Զ���Hash
    // typedef std::unordered_map<IndexKey3, ull, HashFunc3, cmp_fun3> PositionMapType;

    struct Report3
    {
        ull num_of_access;
        ull current_stash_size;
        ull max_stash_size;
        ull last_stash_evict;
        ull total_bandwidth;
        ull bandwidth_per_query;
        ull num_of_real_blocks;
        ull num_of_real_blocks_in_tree;
        int num_of_positionmap;
        ull num_of_AES;
        ull num_of_AES_decrypt;
        ull num_of_Black2b;
        double t1;
        double t2;
        double t3;
        double t4;
        int height;
        int capacity;
        int u;
    };

    enum OP_TYPE
    {
        OPTYPE_ASSIGN = 0,
        OPTYPE_ADD
    };

    class OSAM
    {
    public:
        OSAM(int height, int Z, int u);
        ull KeyToLeaf(IndexKey3 indexkey);
        ull strKeyToLeaf(std::string mainKey);
        IndexKey3 ToIndexKey3(std::string str);
        ull GetReadCount(IndexKey3 ik);

        // ʹ���Զ���Hash��unordered_map
        std::unordered_map<IndexKey3, ull, HashFunc3, cmp_fun3>* pPositionMap;
        std::unordered_map<IndexKey3, StashItem, HashFunc3, cmp_fun3> stash;
       // std::vector<StashItem> stashTemp;
        std::unordered_map<std::string, ENode3> oram;
        DataBlock3(*User_Defined_Operation)(DataBlock3 b1, DataBlock3 b2);

        bool Write(std::string key, std::vector<ull> value);
        bool StashAppend(std::string key, std::vector<ull> value);
        DataBlock3 Read(std::string key);

        void updateReport();
        void dumpLevels();
        void ShowReport();
        ull GetStashSize();
        ull GetN();

        void evictPathsPATHORAM(std::unordered_map<std::string, TreeNode3>& pathNodes, std::vector<unsigned long long> leafs);

        ENodes3 RebuildPaths(std::vector<ull>& leafs);

        void EvictPath(ull v);

        void EncryptPaths(std::unordered_map<std::string, TreeNode3>& pathNodes, ENodes3& enodes);
        void writePath(ENodes3 nodes);
        bool isEmptyBlock(DataBlock3& b);
        void WriteIntoStash(ENodes3 enodes);
        void dump();
        void simpleDump();

        Report3 report;

        int m_L;
        int m_Z;
        int m_u;
        int m_capacity;
        int m_firstLeafID;
        int m_leafCount;

    private:
        void init();
        ENode3 EncryptNode(TreeNode3 d);
        ENodes3 EncryptNodes(TreeNodes3 d);
        TreeNodes3 DecryptNodes(ENodes3 e);
        TreeNode3 DecryptNode(ENode3 e);
        ENodes3 ReadPath(unsigned long long leaf);
        void initAES();

        std::vector<std::vector<ull>> oneNode;
    };

    std::unordered_map<IndexKey3, ull, HashFunc3, cmp_fun3>* GenPositionMap();
}

// ���ȷʵ��Ҫstd::hash�ػ������Ƽ������������Ҫ�ã�
// ������IndexKey3��ȫ����֮�������κ�ʹ��֮ǰ
namespace std {
    template<>
    struct hash<SAM::IndexKey3> {
        size_t operator()(const SAM::IndexKey3& key) const {
            // ��ȫ��ʵ�֣�����δ�������
            uint64_t value;
            memcpy(&value, key.buf, sizeof(value));
            return hash<uint64_t>{}(value);
        }
    };
}