Install:

Windows 10 (64bits) + Visual Studio 2022

