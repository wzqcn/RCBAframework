#include "matrixO3AD.h"

DataBlock3 mymatrixO3ADOperation(DataBlock3 b1, DataBlock3 b2)
{
	DataBlock3 b(b1.values.size(), 0);
	//assert(b1.values.size() == 1);
	for (int i = 0; i < b1.values.size(); i++)
	{
		b.values[i] = b1.values[i] + b2.values[i];
	}
	return b;
}

matrixO3AD::matrixO3AD(int height,int n)
{	
	tree = new RWtree(height, 4,n*n);
	tree->pPositionMap = GenPositionMap();
	tree->User_Defined_Operation = mymatrixO3ADOperation;
	m_height = height;
	m_n = n;
}

matrixO3AD::~matrixO3AD()
{
	delete tree->pPositionMap;
	delete tree;
}

vector<ull> matrixO3AD::Read(string key)
{
	DataBlock3 b = tree->Read(key);
	if (b.values.size() == 0) return b.values;
	return b.values;
}

void matrixO3AD::Write(string key, vector<ull> m)
{
	tree->Write(OPTYPE_ASSIGN, key, m);
}

void matrixO3AD::Add(string key, vector<ull> m)
{
	tree->Write(OPTYPE_ADD, key, m);

}
