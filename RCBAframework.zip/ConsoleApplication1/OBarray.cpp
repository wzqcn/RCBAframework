#include "OBarray.h"

OBarray::OBarray(ull n)
{
	m_n = n;
	m_c = 0;
	m_k = IntToStr(rand64());
}

void OBarray::update(ull i, OP_TYPE op, DataBlock3 v)
{
	r.write_t3 = time_ms();
	RCBA::write(m_k + IntToStr(i), m_c,op, v);
	r.write_t4 = time_ms();
	r.write_bandwidth_perquery = RCBA::owam->report.bandwidth_per_query;
	r.total_bandwidth += r.write_bandwidth_perquery;
}

DataBlock3 OBarray::read(ull i)
{
	DataBlock3 result;
	r.read_t1 = time_ms();
	for (ull j = 0; j < m_n; j++)
	{
		DataBlock3 v=RCBA::copy(m_k + IntToStr(j), m_c,1);
		if (j == i)
			result = v;
	}
	m_c++;
	r.read_t2 = time_ms();
	r.read_bandwidth_perquery = RCBA::owam->report.bandwidth_per_query*m_n;
	r.total_bandwidth += r.read_bandwidth_perquery;
	return result;
}

DataBlock3 OBarray::free()
{
	DataBlock3 result;
	for (ull j = 0; j < m_n; j++)
	{
		 RCBA::read(m_k + IntToStr(j), m_c);
	}
	return result;
}

void OBarray::ShowReport()
{
	printf("OBarray: L=%d Z=%d u=%d size=%lld\n", RCBA::owam->report.height, RCBA::owam->m_Z, RCBA::owam->m_u, m_n);
	printf("read time:%llf(ms)\n", r.read_t2 - r.read_t1);
	printf("write time:%llf(ms)\n", r.write_t4 - r.write_t3);
	printf("read bandwith per query:%lld (bytes)\n", r.read_bandwidth_perquery);
	printf("write bandwith per query:%lld (bytes)\n", r.write_bandwidth_perquery);
	printf("total bandwidth:%lld (bytes)\n", r.total_bandwidth);
}
void TestOBarray()
{
	//
}