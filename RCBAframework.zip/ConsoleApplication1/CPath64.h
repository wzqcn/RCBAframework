#pragma once
#include <string>
using namespace std;
class CPath64 //
{
public:
	CPath64();
	CPath64(long long node_value); //
	CPath64 LeftChild();//
	CPath64 RightChild();//
	CPath64 Sibiling();//
	CPath64 Father();//
	string ToString();//
	CPath64 Cross(long long leaf1, long long leaf2);//


	string P(long long x_LID, int l, int height);
	string AtLevelPath(int l);
	unsigned long long AtLevelPathFast(int l,int L);

	void LoadPath(string path); //
	void LoadLeaf(int level,long long leaf);//
	unsigned long long MapToRandomLeaf(int height);
	unsigned long long RandomLeaf(int height);

	
	unsigned long long GetLeaf();//
	unsigned long long value; //
	
	int GetLevel();//
	~CPath64();
};

unsigned long long GetFatherNumber(unsigned long long node);
unsigned long long GetLeftChildNumber(unsigned long long node);//2*I+1
unsigned long long GetRightChildNumber(unsigned long long node);//2*I+2
string NumberToPath(unsigned long long node);
unsigned long long PathToNumber(string path);

