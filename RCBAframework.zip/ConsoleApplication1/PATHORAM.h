#pragma once

#include "common.h"
#include "unordered_map"
#include "CPath64.h"
#include "myhash.h"
#include "myAES.h"
#include <vector>
#include <algorithm>
#include <string>
//#include "ORAMtree.h"
#define ull unsigned long long
#define DUMMY_VALUE 888888888888



struct IndexKey2
{
	unsigned char buf[8];//
};
struct DataBlock2
{
	vector<ull> values;//
	void Init(int u)
	{
		for (int i = 0; i < u; i++)
		{
			values.push_back(DUMMY_VALUE);
		}
	}
	bool isEmpty()
	{
		for (auto i : values)
		{
			if (i != DUMMY_VALUE) return false;
		}
		return true;
	}
};

struct Slot2
{
	IndexKey2 key;
	DataBlock2 value;//
	ull leaf;
	void GenEmptySlot(int u)
	{
		memset(&key, 0, sizeof(key));
		value.values.clear();
		for (int i = 0; i < u; i++)
		{
			value.values.push_back(DUMMY_VALUE);
		}
	}
	bool isEmpty()
	{
		for (auto i : value.values)
		{
			if (i != DUMMY_VALUE) return false;
		}
		return true;
	}
};

struct TreeNode2
{
	vector<Slot2> slots;
	int level;
	string path;
	void GenEmptyNode(int Z,int u)
	{
		DataBlock2 db;
		Slot2 sl;
		sl.key = { 0 };
		db.values.clear();
		for(int i=0;i<u;i++) db.values.push_back(DUMMY_VALUE);
		sl.value = db;
		sl.leaf = 0;
		slots.clear();
		for(int i=0;i<Z;i++)
		{ 
			slots.push_back(sl);
		}
	}
	bool isEmpty()
	{
		for (auto s : slots)
		{
			if (!s.isEmpty()) return false;
		}
		return true;
	}
};

typedef unordered_map<string, TreeNode2*> TreeNodes2;

struct hash_func2
{
	size_t operator()(const IndexKey2& addr) const
	{
		return *(ull*)addr.buf;
	}
};
struct cmp_fun2 //�ȽϺ��� ==
{
	bool operator()(const IndexKey2& a1, const IndexKey2& a2) const
	{
		return memcmp(a1.buf, a2.buf, sizeof(a1)) == 0 ? true : false;
	}
};

struct Report
{
	ull num_of_access;//
	ull current_stash_size;//
	ull max_stash_size;//
	ull last_stash_evict;//
	ull total_bandwidth;//
	ull bandwidth_per_query;//	
	ull num_of_real_blocks;//
	ull num_of_real_blocks_in_tree;//
	int num_of_positionmap;//
	ull num_of_AES;//
	ull num_of_AES_decrypt;//
	ull num_of_Black2b;//
	int height;//
	int capacity;// 
	int u;//	
};

struct ENode
{
	//vector<Slot> slots;
	vector<unsigned char> bytes;
	int level;
	string path;
};
typedef unordered_map<string, ENode> ENodes;
class PATHORAM
{
	public: PATHORAM(int height, int Z,int u);
		  ull KeyToInt(string mainKey);
		  void GetSubKey(ull mainKey, ull& subkey_x, ull& subkey_y);

		  unordered_map<string, ENode> oram;
		  PATHORAM* pPositionMap;
		  unordered_map<IndexKey2, Slot2, hash_func2, cmp_fun2> stash;

		  bool WriteStashValue(IndexKey2 key, ull y, ull data);
		  bool WriteStashLeaf(IndexKey2 key, ull y, ull data, ull leaf);

		  bool Access(string op, ull x, ull y, ull& result, ull newLeaf);

		  bool Access(string op, string key, DataBlock2& b);
		  bool WriteStash(IndexKey2 key, ull y, ull input_data);
		  bool WriteStash(IndexKey2 key, DataBlock2 input_data);
		  bool ReadStash(IndexKey2 key, DataBlock2& output_data);
		  void updateReport();
		  void dumpLevels();
		  int GetBandwidth();
		  int GetTotalNumberOfInteractions();
		  void ShowReport();
		  ull GetStashSize();
		  ull GetN();
		  bool ReadStash(IndexKey2 key, ull y, ull& output_data);



		  vector<ull> Read(string key);
		  void Write(string key, vector<ull> b2);


		  void evictPathsPATHORAM(unordered_map<string, TreeNode2>& pathNodes, vector<unsigned long long> leafs);

		  ENodes RebuildPaths(vector<ull>& leafs);

		  void EvictPath(ull v);

		  void EncryptPaths(unordered_map<string, TreeNode2>& pathNodes, ENodes& enodes);
		  void writePath(ENodes nodes);
		  bool isEmptyBlock(DataBlock2& b);

		  Report report;

private:
	void init();
	ENode EncryptNode(TreeNode2 d);
	ENodes EncryptNodes(TreeNodes2 d);
	TreeNodes2 DecryptNodes(ENodes e);
	TreeNode2 DecryptNode(ENode e);
	ENodes ReadPath(unsigned long long leaf);
	void WriteIntoStash(ENodes enodes);
	void initAES();


	IndexKey2 ToIndexKey2(ull i);

	bool AccessOneNode(string op, ull x, ull y, ull& result, ull newValue1);

	void WriteBlock(string w, DataBlock2 block);
	int m_L;
	int m_Z;
	int m_u;
	int m_capacity;
	int m_firstLeafID;
	int m_leafCount;
	vector<vector<ull>> oneNode;
};

