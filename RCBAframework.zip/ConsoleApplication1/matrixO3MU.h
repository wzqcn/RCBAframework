#pragma once
#include "RWtree.h"
class matrixO3MU
{
public:
	matrixO3MU(int height,int n);
	~matrixO3MU();
	vector<ull> Read(string key);
	void Write(string key, vector<ull> matrix);
	void Mul(string key, vector<ull> matrix);
	RWtree* tree;
	int m_height;
};

