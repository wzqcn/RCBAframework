
#include "PATHORAM.h"
#include "math.h"

PATHORAM::PATHORAM(int height, int Z,int u)
{
	m_L = height;
	m_Z = Z;
	m_u = u;
	init();
}

//mainKey  [0, N-1]

ull PATHORAM::KeyToInt(string mainKey)
{
	unsigned char buf[32] = { 0 };
	myhash::Blake2b((void*)mainKey.c_str(), mainKey.length(), buf);
	report.num_of_Black2b++;
	ull v = *(ull*)buf;
	ull cap = (ull)pow(2, m_L); // (ull)pow(2, m_L - 1)* m_Z;
	v= v% (ull)cap;//
	return v;
}

void PATHORAM::GetSubKey(ull mainKey, ull& subkey_x, ull& subkey_y)
{	
	subkey_x = mainKey /m_u;
	subkey_y = mainKey % m_u;
}



vector<ull> PATHORAM::Read(string key)
{
	DataBlock2 block;	
	Access("read", key, block);
	vector<ull> r;
	for (int i = 0; i < block.values.size(); i++)
	{
		if (block.values[i] != DUMMY_VALUE)
		{
			r.push_back(block.values[i]);
		}
	}
	return r;
}
void PATHORAM::Write(string key, vector<ull> b2)
{
	
	DataBlock2 block;
	for (int i = 0; i < m_u; i++)//
	{
		if (i < b2.size())
		{
			block.values.push_back(b2[i]);
		}
		else
		{
			block.values.push_back(DUMMY_VALUE);//
		}
	};
	
	Access("write", key, block);
	return ;
}


void PATHORAM::init()
{
	pPositionMap = NULL;
	m_capacity = pow(2, m_L)-1;// +1;
	m_firstLeafID = pow(2, m_L - 1) - 1;
	m_leafCount = pow(2, m_L - 1);
	ull mem = m_capacity * m_Z * 5;//
	ull maxMem = pow(2, 26);
	if (mem > oram.max_bucket_count()) mem = oram.max_bucket_count();//
	if (mem > maxMem) mem = maxMem;//
	oram.reserve(mem);
	initAES();
	if (m_capacity<=m_u)
	{
		pPositionMap = NULL;
	}
	else
	{
		double h=floor(log2(m_capacity/m_u));//	
		int m_L2 = (int)h;
		pPositionMap = new PATHORAM(m_L2, m_Z, m_u);
		report.num_of_positionmap++;
	};

	memset(&report, 0, sizeof(report));
	report.u = m_u;
	report.height = m_L;
	report.capacity = m_capacity;
}

ENode PATHORAM::EncryptNode(TreeNode2 d)
{
	ENode ed;
	ed.level = d.level;
	ed.path = d.path;

	Slot2 s;
	s.GenEmptySlot(m_u);
	if (d.slots.size() == 0)
	{		
		for (int i = 0; i < m_Z; i++)
		{
			d.slots.push_back(s);
		}
	}
	int slotSize = sizeof(IndexKey2) + m_u * sizeof(ull) + sizeof(ull);
	int insize = d.slots.size() * slotSize;
	int outsize = 0;

	char* m = (char*)malloc(insize);
	char* output = (char*)malloc(insize * 2);
	char* p = NULL;
	for (int i = 0; i < d.slots.size(); i++)
	{
		p = m + i * slotSize;
		memcpy(p, (char*)&d.slots[i].key, sizeof(d.slots[i].key));
		p += sizeof(d.slots[i].key);//
		for (int j = 0; j < d.slots[i].value.values.size(); j++)
		{
			memcpy(p, (char*)&d.slots[i].value.values[j], sizeof(ull));//
			p += sizeof(ull);
		}
		memcpy(p, (char*)&d.slots[i].leaf, sizeof(ull));//
	}
	
	myAES::Encrypt(m, insize, output, outsize);//
	report.num_of_AES++;
	for (int i = 0; i < outsize; i++)
	{
		ed.bytes.push_back(output[i]);//
	}
	free(output);
	free(m);

	return ed;
}

TreeNode2 PATHORAM::DecryptNode(ENode e)
{
	TreeNode2 d;
	d.GenEmptyNode(m_Z, m_u);
	int insize = e.bytes.size();
	char* m = (char*)malloc(insize);
	for (int i = 0; i < insize; i++)
	{
		m[i] = e.bytes[i];
	}
	char* plaintext = (char*)malloc(insize);
	int outsize = 0;
	int slotSize = sizeof(IndexKey2) + m_u * sizeof(ull) + sizeof(ull);
	myAES::Decrypt(m, insize, plaintext, outsize);
	report.num_of_AES_decrypt++;
	int outBlock = outsize / slotSize;//

	char* p1 = m;
	char* p2 = plaintext;
	int len = 0;
	//outBlock==m_Z
	for (int i = 0; i < outBlock; i++)
	{
		p1 = (char*)&d.slots[i].key;
		memcpy(p1, p2, sizeof(d.slots[i].key));//
		p2 += sizeof(d.slots[i].key);
		for (int j = 0; j < m_u; j++)
		{
			p1 = (char*)&d.slots[i].value.values[j];
			memcpy(p1, p2, sizeof(ull));//
			p2 += sizeof(ull);
		}
		p1= (char*)&d.slots[i].leaf;
		memcpy(p1, p2, sizeof(ull));//
		p2 += sizeof(ull);
	}
	free(m);
	free(plaintext);
	return d;
}


ENodes PATHORAM::EncryptNodes(TreeNodes2 d)
{
	ENodes temp;
	for (auto v : d)
	{		
		auto value = EncryptNode(*v.second);
		temp[v.first] = value;
	}
	return temp;
}

TreeNodes2 PATHORAM::DecryptNodes(ENodes e)
{
	TreeNodes2 t;
	for (auto v : e)
	{
		TreeNode2* t1 = new TreeNode2();
		*t1 = DecryptNode(v.second);
		t[v.first] = t1;
	}
	return t;
}

ENodes PATHORAM::ReadPath(unsigned long long leaf)
{
	CPath64 p(leaf);
	ENodes nodes;
	while (true)
	{
		string path = p.ToString();
		if (oram.find(path) == oram.end())
		{
			ENode empty;
			empty.path = path;
			empty.level = p.GetLevel();
			nodes[path] = empty;
			if (p.value == 0) break;
			p = p.Father();
			continue;
		}
		ENode n = oram[path];
		nodes[path] = n;
		if (p.value == 0) break;
		p = p.Father();
	}
	return nodes;
}

bool PATHORAM::isEmptyBlock(DataBlock2& b)
{	
	for (int i = 0; i < m_u; i++)
	{
		if (b.values[i] != DUMMY_VALUE) return false;
	}
	return true;
}

void PATHORAM::WriteIntoStash(ENodes enodes)
{
	for (auto v : enodes)
	{
		TreeNode2 d = DecryptNode(v.second);
		for (auto& s : d.slots)
		{
			if (isEmptyBlock(s.value)) continue;//
			stash[s.key] = s; //
		}
	}
}

void PATHORAM::initAES()
{
	myAES::SetPrivateKey((char*)"12345678");
}



IndexKey2 PATHORAM::ToIndexKey2(ull i)
{	
	return *(IndexKey2*)&i;
}


bool PATHORAM::AccessOneNode(string op, ull x, ull y, ull& result,ull newValue1)
{
	ull v = 0;

	ull input=0, output=0;
	bool bExist = false;
	bExist=ReadStash(ToIndexKey2(x), y,result);//
	WriteStashLeaf(ToIndexKey2(x), y, newValue1,0);//
	return bExist;
}


bool PATHORAM::Access(string op, ull x,ull y, ull& result,ull newLeaf)
{
	if (y >= m_u)
	{
		printf("index out of range!\r\n");
		return false;
	};
	report.num_of_access++;//
	if (!pPositionMap)//
	{
		return AccessOneNode(op, x, y, result,newLeaf);
	};
	ull x1, y1;
	ull leaf2;
	GetSubKey(x, x1, y1);
	ull newValue = CPath64(0).RandomLeaf(m_L);//
	ull v = 0;
	bool b=pPositionMap->Access("read", x1, y1, v,newValue);//

	if (!b || (v == DUMMY_VALUE))
	{
		v = CPath64(0).RandomLeaf(m_L);//
	};
	auto path=ReadPath(v);
	WriteIntoStash(path);
	bool bExist=false;

	if (op == "write")
	{
		bExist = WriteStash(ToIndexKey2(x), y, result);
	}
	else
	{
		bExist = ReadStash(ToIndexKey2(x), y, result);
	}
	WriteStashLeaf(ToIndexKey2(x), y, newLeaf,newValue);

	EvictPath(v);//


	report.current_stash_size = stash.size();
	if (report.max_stash_size < report.current_stash_size) report.max_stash_size = report.current_stash_size;
	return bExist;
}

bool PATHORAM::Access(string op, string key, DataBlock2& b1)
{
	ull x, y;
	ull x0=KeyToInt(key);
	report.num_of_access++;
	GetSubKey(x0, x, y);

	ull x1, y1;
	ull leaf2;
	GetSubKey(x, x1, y1);
	ull newValue = CPath64(0).RandomLeaf(m_L);//
	ull v = 0;
	bool bExist1 = pPositionMap->Access("read", x1, y1, v,newValue);//

	if (!bExist1 ||(v == DUMMY_VALUE))
	{
		v = CPath64(0).RandomLeaf(m_L);//
	};
	auto path = ReadPath(v);
	WriteIntoStash(path);
	bool bExist;


	if (op == "write")
	{
		bExist = WriteStash(ToIndexKey2(x), b1);
	}
	else
	{
		bExist = ReadStash(ToIndexKey2(x),b1);
	}
	if (b1.values.size() == 0)
	{
		b1.Init(m_u);
	};
	WriteStashLeaf(ToIndexKey2(x), y,b1.values[y], newValue);//

	EvictPath(v);//
	report.current_stash_size = stash.size();
	if (report.max_stash_size < report.current_stash_size) report.max_stash_size = report.current_stash_size;
	return bExist;
}



void PATHORAM::evictPathsPATHORAM(unordered_map<string, TreeNode2>& pathNodes, vector<unsigned long long> leafs)
{
	//vector< IndexKey2> toBeDelete;
	int num_of_evict = 0;
	for (int i = m_L; i >= 1; i--)
	{
		for (auto leaf : leafs)
		{
			CPath64 currentLeaf(leaf);
			TreeNode2 node;
			//string p1 = currentLeaf.AtLevelPath(i);
			ull p1long = currentLeaf.AtLevelPathFast(i, m_L);
			string p1 = NumberToPath(p1long);
			node = pathNodes[p1];//
			//toBeDelete.clear();
			node.path = p1;
			node.level = i;
			for (auto v = stash.begin(); v != stash.end();)
			{
				//int level = path64.Cross(leaf, v.second.leaf).GetLevel();	
				double t1 = time_ms();
				ull p2long = CPath64((*v).second.leaf).AtLevelPathFast(i, m_L); //
				double t2 = time_ms();
			    

				if (p1long == p2long) //
				{
					Slot2 s;
					IndexKey2 k0;
					k0 = v->first;
					s = (*v).second;
					if (node.slots.size() < m_Z) //
					{
						node.slots.push_back(s);
						v++;
						stash.erase(s.key);
						num_of_evict++;
					}
					else
					{
						v++;
						break;//
					}
					pathNodes[p1] = node;
				}
				else
				{
					v++;
				}
			}

		}
	}

	report.last_stash_evict = num_of_evict;
}


ENodes PATHORAM::RebuildPaths(vector<ull>& leafs) //
{
	unordered_map<string, TreeNode2> nodes;
	evictPathsPATHORAM(nodes, leafs);
	ENodes enodes;
	EncryptPaths(nodes, enodes);//
	return  enodes;	
}


void PATHORAM::EvictPath(ull v)
{
	int stashSize = stash.size();
	if (stashSize == 0) return;
	vector<ull> leafs = { v };
	ENodes enodes = RebuildPaths(leafs); //
	writePath(enodes);//
	
	int size = 0;
	for (auto& x: enodes)
	{
		//
		size+=x.second.bytes.size();
	}
	report.bandwidth_per_query = size * 2;
	report.total_bandwidth += size*2;
}

void PATHORAM::EncryptPaths(unordered_map<string, TreeNode2>& pathNodes, ENodes& enodes)
{
	for (auto& v : pathNodes)
	{
		TreeNode2 node = v.second;

		if (v.first != "")
		{
			while (node.slots.size() < m_Z) //
			{
				Slot2 empty;
				empty.GenEmptySlot(m_u);				
				node.slots.push_back(empty);
			}
		}
		node.path = v.first;
		node.level = v.first.length() + 1;
		if (node.level == 1) //
		{
			while (node.slots.size() < m_Z) //
			{
				Slot2 empty;
				empty.GenEmptySlot(m_u);
				node.slots.push_back(empty);
			}
		}
		ENode enode = EncryptNode(node);
		enodes[node.path] = enode;
	}
}

void PATHORAM::writePath(ENodes nodes)
{
	for (auto d : nodes)
	{
		oram[d.first] = d.second;
	}
}


bool PATHORAM::WriteStashLeaf(IndexKey2 key, ull y,ull data,ull leaf)
{
	CPath64 p64;
	bool bExist = false;

		Slot2 s0;
		if (stash.find(key) == stash.end()) //
		{			
			s0.GenEmptySlot(m_u);
			s0.key = key;
			s0.value.values[y] = data;//
			s0.leaf = leaf;//
			stash[key] = s0;
			bExist = false;
		}
		else
		{
			s0 = stash[key];
			s0.value.values[y] = data;
			s0.leaf = leaf;
			stash[key] = s0;
			bExist = true;
		}
	return bExist;
}




bool PATHORAM::WriteStash(IndexKey2 key, ull y,ull input_data)
{
	CPath64 p64;
	bool bExist = false;
		Slot2 s;
		if (stash.find(key) == stash.end()) //
		{
			bExist = false;
			s.GenEmptySlot(m_u);
			s.key = key;
			s.value.values[y] = input_data;
			stash[key] = s;
		}
		else
		{ 
			Slot2 s;
			s = stash[key];
			s.value.values[y] = input_data;		
			stash[key] = s;
			bExist = true;
		}		
	return bExist;
}

bool PATHORAM::ReadStash(IndexKey2 key, ull y, ull& output_data)
{
	CPath64 p64;
	bool bExist = false;
	Slot2 s;
	if (stash.find(key) == stash.end()) //
	{
		bExist = false;
		output_data = 0;
	}
	else
	{
		Slot2 s;
		output_data = stash[key].value.values[y];
		bExist = true;
	}
	return bExist;
}
bool PATHORAM::WriteStash(IndexKey2 key, DataBlock2 input_data)
{
	CPath64 p64;
	bool bExist = false;
	Slot2 s;
	if (stash.find(key) == stash.end()) //
	{
		bExist = false;
		s.GenEmptySlot(m_u);
		s.key = key;
		s.value = input_data;
		stash[key] = s;
	}
	else
	{
		Slot2 s;
		s = stash[key];
		s.value = input_data;
		stash[key] = s;
		bExist = true;
	}
	return bExist;
}
bool PATHORAM::ReadStash(IndexKey2 key, DataBlock2& output_data)
{
	CPath64 p64;
	bool bExist = false;
		if (stash.find(key) == stash.end()) //
		{
			bExist = false;			
		}
		else
		{
			Slot2 s = stash[key];
			output_data = s.value;
			bExist = true;
		}
	return bExist;
}


void PATHORAM::updateReport()
{
	//
	unordered_map<ull, ull> levelReal;
	unordered_map<ull, ull> levelEmpty;
	report.num_of_real_blocks = 0;
	report.num_of_real_blocks_in_tree = 0;
	for (auto v : oram)
	{
		ull level = v.first.length() + 1;
		auto node = v.second;
		auto node2 = DecryptNode(node);
		for(auto s:node2.slots)
		{
			if (s.isEmpty())
			{
				levelEmpty[level]++;
			}
			else
			{
				levelReal[level]++;
				report.num_of_real_blocks++;
				report.num_of_real_blocks_in_tree++;
			}
		}
	}
	report.num_of_real_blocks += stash.size();
}
void PATHORAM::dumpLevels()
{
	//
	unordered_map<ull, ull> levelReal;
	unordered_map<ull, ull> levelEmpty;

	for (auto v : oram)
	{
		ull level = v.first.length() + 1;
		auto node = v.second;
		auto node2 = DecryptNode(node);
		for (auto s : node2.slots)
		{
			if (s.isEmpty())
			{
				levelEmpty[level]++;
			}
			else
			{
				levelReal[level]++;
			}
		}
	}
	for (int i = 1; i < m_L; i++)
	{	
		ull r = levelReal[i];
		ull e = levelEmpty[i];
		ull f = r + e;
		if (f > 0)
		{
			printf("Level=%d total=%lld used=%lld unsued=%lld usage=%.2f%%\r\n", i, f, r, e, (double)r / f*100);
		}
		else
		{
			printf("Level=%d total=%lld used=%lld unused=%lld usage=0%%\r\n", i, f, r, e, 0);
		}
	}
	printf("Stash size:%lld #blocks:%lld\r\n",stash.size(),report.num_of_real_blocks_in_tree);
}
int PATHORAM::GetBandwidth()
{
	PATHORAM* p = this;
	int b = 0;
	do
	{
		b += p->report.bandwidth_per_query;
		p = p->pPositionMap;
	} while (p);
	return b;
}
int PATHORAM::GetTotalNumberOfInteractions()
{
	PATHORAM* p = this;
	int result = 0;
	do
	{
		result += p->report.num_of_access;
		p = p->pPositionMap;
	} while (p);
	return result;
}

void PATHORAM::ShowReport()
{
	Report r;
	PATHORAM* p = this;
	do
	{
		p->updateReport();
		r = p->report;
		//....
		p->dumpLevels();

		p= p->pPositionMap;
	} while (p);
}
ull PATHORAM::GetStashSize()
{
	ull size = 0;
	PATHORAM* p = this;
	do
	{		
		size += p->stash.size();
		p = p->pPositionMap;
	} while (p);
	return size;
}
ull PATHORAM::GetN()
{
	updateReport();
	return report.num_of_real_blocks_in_tree;
}

