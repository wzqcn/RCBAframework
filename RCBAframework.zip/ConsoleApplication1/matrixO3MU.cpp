#include "matrixO3MU.h"

#include <vector>
#include <cmath>

std::vector<ull> matrixMultiply(const std::vector<ull>& b1, const std::vector<ull>& b2) 
{
	ull size = b1.size();
	
	if (b2.size() != size) 
	{
		throw std::invalid_argument("b1 and b2 must have the same size");
	}
	ull n = std::sqrt(size);
	if (n * n != size) 
	{
		throw std::invalid_argument("Size must be a perfect square");
	}

	std::vector<ull> c(size, 0); 
	for (ull i = 0; i < n; ++i) {
		for (ull j = 0; j < n; ++j) {
			for (ull k = 0; k < n; ++k) {
				c[i * n + j] += b1[i * n + k] * b2[k * n + j];
			}
		}
	}
	return c;
}

DataBlock3 mymatrixO3MUOperation(DataBlock3 b1, DataBlock3 b2)
{
	bool isZero = true;
	for (auto i : b1.values)
	{
		if (i != 0)
		{
			isZero = false;
			break;
		}
	}
	if (isZero)
	{
		return b2;
	}
	DataBlock3 d;
	d.values = matrixMultiply(b1.values, b2.values);
	return d;
}

matrixO3MU::matrixO3MU(int height,int n)
{
	tree = new RWtree(height, 4, n*n);
	tree->pPositionMap = GenPositionMap();
	tree->User_Defined_Operation = mymatrixO3MUOperation;
	m_height = height;
}

matrixO3MU::~matrixO3MU()
{
	delete tree->pPositionMap;
	delete tree;
}

vector<ull> matrixO3MU::Read(string key)
{
	DataBlock3 b = tree->Read(key);
	if (b.values.size() == 0) return b.values;
	return b.values;
}

void matrixO3MU::Write(string key, vector<ull> m)
{
	tree->Write(OPTYPE_ASSIGN, key, m);
}

void matrixO3MU::Mul(string key, vector<ull> m)
{
	tree->Write(OPTYPE_ADD, key, m);

}
